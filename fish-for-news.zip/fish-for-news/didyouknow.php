<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/red.css" rel="stylesheet" />         
    	   <script src="files/js/jquery-1.7.1.min.js"></script>
    	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>    




    
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/red/banner_red.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>          
            <li class="menuitem"><a href=".">Home</a></li>
	        <li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>          
            <li class="menuitem"><a href="Happenings/prerana.html">Happenings</a></li>          
            <li class="menuitem"><a href="framed.php">Framed</a></li>          
            <li class="menuitem"><a href="kaleidoscope.php">Kaleidoscope</a></li>  
            <li class="selected">Viva Goem</li>
            <li class="menuitemn"><a href="contactUs.php">Contact Us</a></li>                            
          </ul>             
        </div>  
        <div id="submenu">
			<ul>                                                                         
				<li class="selectedleft"><a href="#">Did you know</a></li>                                                                
				<li class="submenuitem"><a href="viva_goem.php">The Basket Weaver</a></li>
			</ul>
        </div>             
		
        <div id="content">	                   
          <div class="articleTitle fontClass" style="padding-top:10px;">A PANORAMIC VIEW FROM OLD GOA<br  /></div><br>
		  <div  style="text-align:center;"><img id="mainPic" class="shadow normal" src="files/images/oldGoa.jpg"   ><br  /></div>
		  <div >
		  <br>
		 
		  <p>In Old Goa there is a church every 100 meters or at least 300 meters. This captivating view taken from a hill top shows many of the churches. In the above view clearly shows  the Pastoral Institute of St Pius X , anciently known as St Cajetan church designed to look like the St Peter church in Rome, followed by the Se Catheral church, very close to it is the Basilica of Bom Jesus. In the corner are the ruins of St Augustine and close to its heels is the convent of St Monica now used by the Mater Dei institute as a nunnery. A little furtheris the  Church of Our lady of Rosary. </p>
<p>If you are a history seeker, then this place, which was once the capital of Goa during the Portuguese rule would be the place you would want to drop by and spend the entire day researching the past truth.
 </p>
 
 </div>

	  
		  

		  <p><b>
Here is a chance for all you amateur photographers to submit one of your best photographs on any cultural/ancestral aspects of  Goa.
 A short description on the photograph can be submitted. Send in your contribution to 
 
		  <span style="color:#0000FF;">goanews@persistent.co.in</span></b></p>
		  
        </div>
		<p><img src="files/images/footer-image-ameya.jpg"></p>
                                    
      </div>
      <div id="footer">                                                 
        <p>Copyright &copy; 2013 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>
    </div>  
  </body>
</html>