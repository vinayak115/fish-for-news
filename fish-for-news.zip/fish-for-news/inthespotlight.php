<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="generator" content=
    "HTML Tidy for Windows (vers 25 March 2009), see www.w3.org" />
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>
      Goa Newletter
    </title>
    <style type="text/css">

    #content p { text-align:justify; margin: 10px;line-height:18px;}
  
    </style>
  </head>
  <body>
    <div id="outdiv">
      <div id="header">
        �
      </div>
      <div id="container">
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" />
        </div>
        <div id="menu">
          <ul>
            <li class="menuitem">
              <a href=".">Home</a>
            </li>
            <li class="menuitem">
              <a href="technobyte.php">Techno Byte</a>
            </li>
            <li class="menuitem">
              <a href="Happenings/prerana.html">Happenings</a>
            </li>
            <li class="menuitem">
              <a href="framed.php">Framed</a>
            </li>
            <li class="selected">Kaleidoscope
            </li>
            <li class="menuitemn">
              <a href="didyouknow.php">Viva Goem</a>
            </li>
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a>
            </li>
          </ul>
        </div>
        <div id="submenu">
        <ul>
	    
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="selected"><a href="#">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>
		
		</ul>
        </div> 
		
        <div id="content">
          <h1>
            In The Spotlight
          </h1><img src="files/images/inthespotlight/inthespotlight.jpg" alt="" style=
          "float:right; margin-left:15px;" />
          <p>
            <b>Name:</b> Marwin Menezes
	<br> 
	</p>
          <p>
           <b>Pet name: </b>none stuck fortunately or un fortunately  <img src="files/images/wink_smile.gif">
			<br>
		  </p>
		  
		  <p><b>You have been with the Persistent family for quite sometime now, what has given you immense joy and what has been you greatest enemy here ?</b> 
		  <!--<img src="files/images/1.gif">-->
			<br> 
			Working with talented folks is always fun and enjoyable. To my good luck I have been privileged to work with quite a few of them in my years in persistent. Enemies I am not sure I have any in persistent (that I know of)
		  </p>		  
		  
		  <p>
            <b>Apart from coding, your hobbies are ?</b>
			<br>I would say traveling, gardening and writing are some of the things I like doing besides coding
			<br>
		  </p>		  
		 
		  <p><b>A thing yet to be explored ?</b> <br>
		 Europe is one place that I have not yet explored. Hopefully will get a chance to do it in the near future. <!--<img src="files/images/small_smile.jpg"> -->
 			<br>
			</p>		  
          
		  <p>
            <b>What do you hate about traffic jams ? </b> 
			<br>People who honk when they know that there is no way through and bikers who cut lanes and create further confusion.  
			<!--<img src="files/images/1.gif">--><br>         
			 </p>
		 
          <p>
            <b>You are the son of the soil and head from a beautiful village of Goa, Divar, what can you boast of it ? </b>
            <br>Divar is a very scenic place. But besides the scenery there are some unique things about the place. It&rsquo;s got some colorful festivals, historic places, vivid architecture, great bird life, intriguing folktales. And most of all fantastic, warm people who have lived in harmony for centuries.<br></p>
			
		<p>
            <b>What do you like about any weddings in Goa ?</b>
            <br>In Goa the ceremonies performed for weddings differ from community to community but what I like is that the values and purpose behind these ceremonies remains the same and people from different communities can relate to them. <br>
		</p>            
			
		 <p>
            <b>Your favorite grand mom dessert ?</b>
            <br>Tough choice because there are so many to choose from, I think the bebinca that was roasted on a wood fired flame is my favorite.  
			<!--<img src="files/images/small_smile.jpg">--><br>
		</p>	 
			
		 <p>
            <b>An award that you always look with great pride ? </b>
            <br>I would say my school physics project that was voted the best science project that year. It was an implementation of the &quot;youngs double slit&quot; experiment. <!--<img src="files/images/3.gif">--><br>
	 </p>		
		
		
			
			<p><b>They say there is a child in every man, do you agree, if yes, why ?</b>
			<br>Yes, I believe that the creative and adventurous part of a person comes from the fact that we all have a child in us. </p>
			
			<p><b>A dream yet to be fulfilled ?</b><br>
I have set goals for myself that I would like to be fulfilled. I never reveal my goals <img src="files/images/small_smile.jpg"></p>
			
			<p> &nbsp; </p>
		  <p> &nbsp; </p>
		  
		  
        </div><img src="files/images/authors/nadia.jpg" />
      </div>
      <div id="footer">
        <p>
          Copyright &copy; 2013 Persistent Systems Ltd.
        </p>
      </div>
    </div>
  </body>
</html>