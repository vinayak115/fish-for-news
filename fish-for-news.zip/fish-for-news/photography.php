<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">                 
    <head>                             
        <link type="text/css" href="files/css/orange.css" rel="stylesheet" />                             
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />                             
        <title>Goa Newletter                             
        </title>    
<style type="text/css">
.content p
{
text-align:justify;
}
</style>              
    </head>                 
    <body>                          
        <div id="outdiv">                              
            <div id="header">           &nbsp;                              
            </div>                                  
            <div id="container">                                                
                <div id="banner">                                           
                    <img src="files/images/orange/banner.jpg" alt="banner" />                                     
                </div>                                                    
                <div id="menu">                                                             
                    <ul>           		  
                        <li class="menuitem">
                            <a href=".">Home</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="technobyte1.php">Techno Byte</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="Happenings/PAC.html">Happenings</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="framed.php">Framed</a>
                        </li>           		  
                        <li class="selected">
                            Kaleidoscope
                        </li>  		  
                        <li class="menuitemn">
                            <a href="didyouknow.php">Viva Goem</a>
                        </li>         
                        <li class="menuitem">
                            <a href="contactUs.php">Contact Us</a>
                        </li>                            
                    </ul>                                           
                </div>                                        
                <div id="submenu">                                         
                    <ul>
        <li class="left"><a href="kaleidoscope/kaleidoscope.php">Post Cards</a></li>
		<li class="submenuitem"><a href="kitchendom.php">Kitchendom</a></li>
	<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
        <li class="selected"><a href="photography.php">Photography</a></li>
		<li class="submenuitem"><a href="valentine.php">Valentines Day</a></li>
        </ul>                                
                </div>                                                 
                <div id="content">	   
<h1>/Hobbies/Art/Photography </h1>
<p style="text-align:center;">
 <img src="files/images/photography/photo1.jpg"/>   <img src="files/images/photography/photo2.jpg"/> 
</p>
  <p>  When I have time at hand and get to traverse the above folder structure on my personal computer, I almost get lost. With over a 5000 clicks I have learnt the importance of managing my own photo collection. But mind you, I am not going to talk here about any tools to help you out with that.
</p><p>
Photography is a very subjective art. The representation of different colors; which is nothing but the reflection of certain wavelengths of light can mean different things to different people. And why not? A Camera captures not just what is in front of the lens but also what the eye behind the lens wants to see. Photography provides us an infinite canvas where we can put our thoughts, people, fantasies, mother nature and a variety of things into it. Different minds get enticed by different things and thus we end up clicking differently. Now that gets us back to what all a mind is interested in and what all can get enlisted in the folder structure which basically is the title of this article. For me, photography is an art, and though it might be distinctly different from other arts, taking a cue from another art form can help building a composition.
</p><p>  

Having a penchant for little things in nature, I love it when it bumps into me. I like to capture the chirping birds through my camera which once upon a time as a school kid I used to draw on paper to depict an exotic scene or a flock of them on the backdrop of blue sky which I used to draw as a symbol of freedom. The colorful butterflies that formed art book covers also find a rightful place for themselves in my collection. Sometimes I plan a journey in search of greenery, waters, mountains or just the shores when serenity rings my mind. But there are times when I repent going to such beautiful places. Nature is beautiful and this beauty is to be enjoyed by loving every moment spent there. As a photographer I merely end up pushing a button to set my claim on the title of a good photographer whilst I capture this beauty. Good photography is not about capturing the existing beauty but this creative art must add value to the original beauty in your final composition.  I feel compelled to try something extra ordinary, which draws me may be too close to get a macro or a wider angle than usual or just something else. The things I try out - sometimes puts me in spot light and I receive strange stares from the people around me. Their eyes seem to say "what is this man up to?" But artist has not time to waste on things that don't matter to his subjects. At the cost of being ridiculed I go on adding a few megabytes to my memory card.
</p>
<p style="text-align:center;">
 <img src="files/images/photography/photo3.jpg"/>   <img src="files/images/photography/photo7.jpg"/> 
</p>
<p>
Capturing nature's beauty is all about capturing a single moment - but festivals provide an opportunity to capture a string of events that have been celebrated over centuries. These moments are cherished for times to come. The crucial thing here is capturing the right moment.  A natural corollary here is that one day we might find ourselves gazing rapturously at some of these moments and those photographs will come alive in our minds; they may possibly do some hand holding and take us down the distant memory lane when we actually lived those moments. I have a snap of a child running away from a bomb about to explode; her expressions make me fall of my chair in laughter every time I see it. (The bomb is not real bomb, it's the firework bomb).
</p><p>Adventure photography or sports photography gives you an opportunity to test your shutter. Your mind has to anticipate the things that are about to come and then you can freeze the action with the help of your camera. A sporting event is the best time for making your shutter groove to your tunes.
</p>
<p style="text-align:center;">
 <img src="files/images/photography/photo5.jpg"/>   <img src="files/images/photography/photo6.jpg"/> 
</p>
<p>
I always believe that equipment is not the most important thing in photography. People often ask about the camera we use but then in my opinion the camera is just a medium through which we express our self, what we want to express is more important than having a state of art camera.
</p><p>
Falling back to subjects, wildlife is yet another interesting area where you get to experience the beauty in the jungles. This asks for a different zeal and a passion from within. Many people who venture into this hold loads of patience with them. Just like the patient hunter who waits till eternity for its prey and the crocodile which waits relentlessly without moving an inch of its body for a thirsty animal to approach, the photographer too has to be prepared for an affair unbounded by time. It is not about minutes but hours or sometimes even days before you get the moment you were waiting for. Difficult environmental conditions, time, hindrances, weather can spoil the whole thing a lot of times. And all this can wildlife photography a tough job.
</p>
<p style="text-align:center;">
 <img src="files/images/photography/photo4.jpg"/>   <img src="files/images/photography/photo8.jpg"/> 
</p>
<p>
Art photography is about divergent thinking. An art photographer has an eye for things that are many a times not observed by a normal eye. Lighting is an important aspect when it comes to portraying art since good photos are hard to distinguish from paintings. Just like a painter imagines a source of light falling from a particular direction, a photographer needs to devote his attention to the sources of light that are present, which will find their way into his frame and improvise on them. Once an artist chooses the subject and the sources of light, he makes a blend of colors and that is precisely what builds his composition. Keeping the bare minimum objects in your frame and the rest out while keeping the essential objects inside your frame is the only ways of making your photos speak. 
</p><p>
I had warned the readers that this article was not about tools and technology, it's about amateur's experience with photography and a learner's interpretation of art. Thanks for reading <span style="font-size:18px;">&#9786;</span>
       </p>     
<p><img src="files/images/kalieo-foo-saiesh.jpg"/></p>         
      </div>                                  
                                                                   
            </div>                           
            <div id="footer">                                   
                <p>Copyright &copy; 2011 Persistent Systems Ltd.                           
                </p>                                            
            </div>                            
        </div>              
    </body>
</html>