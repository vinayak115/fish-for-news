<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">                          
  <head>                                            
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />                                            
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />                                            
    <title>Goa Newletter                                            
    </title>                             
  </head>                          
  <body>                                         
    <div id="outdiv">                                                   
      <div id="header">           &nbsp;                                                   
      </div>                                                       
      <div id="container">                                                                           
        <div id="banner">                                                                            
          <img src="files/images/orange/banner.jpg" alt="banner" />                                                                
        </div>                                                                              
        <div id="menu">                                                                                  
          <ul>           		                           
            <li class="menuitem">                            
              <a href=".">Home</a>                        
            </li>           		                           
            <li class="menuitem">                            
              <a href="technobyte.php">Techno Byte</a>                        
            </li>           		                           
            <li class="menuitem">                            
              <a href="Happenings/prerana.html">Happenings</a>                        
            </li>           		                           
            <li class="menuitem">                            
              <a href="framed.php">Framed</a>                        
            </li>           		                           
            <li class="selected"> Kaleidoscope                         
            </li>  		                           
            <li class="menuitemn">                            
              <a href="didyouknow.php">Viva Goem</a>                        
            </li>                                  
            <li class="menuitem">                            
              <a href="contactUs.php">Contact Us</a>                        
            </li>                                                 
          </ul>                                                            
        </div>                                                                
        <div id="submenu">
        <ul>
        
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="selected"><a href="#">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>
		<!--<li class="submenuitem"><a href="strings_and_frets.php">Strings And Frets</a></li>-->
		
		</ul>
        </div> 
		
        <div id="content">
		<h1>Brain Teasers</h1>
		<h3>HAVE YOUR SAY</h3>                                         
          <font size="2" color="black"> 
            <p style="text-align:center;">Quote the following picture. The funniest quote will be published in the next issue.</p> 
          </font>                                         
          <p style="text-align:center">                                                 
            <img src="files/images/brainteaser/quotepic_oct2013.jpg" alt="brain teaser" />   
            <br>
            <br>           
            <font size="2" color="black"> Send in your entries to 
            </font> 
            <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in</a>                             
          </p>
		  <h3>Last Quarter Best Entry</h3>		                                        
          <p style="text-align:center">                                                 
            <img src="files/images/brainteaser/lastquarter_oct2013.jpg" alt="last entry" />   
             <br><br><b>&quot;Believe me, I am not responsible for Global Warming! I&rsquo;ve been out on a vacation.&quot;</b>  <br>                                     
          <br><strong>Winner: Somasree Choudhury</strong>
          </p>             
          <br>          
          <br>          <h2>Identify The Singer</h2>            
          <p style="text-align:center">              
            <img src="files/images/brainteaser/identifysinger_oct2013.jpg" alt="Pop Singer"/> 
            <br>
            <br> Mail your entries to 
            </font>
            <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in</a>              
          </p>           <b><strong> Last quarter Answer: Honey Singh </strong>
            <br>
            <br><strong>Winner: Yogesh Naik</strong>
            <br>
            <br>Other correct entries were from :
			<ul>
			<li>Sairaj Kalekar</li>
			<li>Kavya Goyal</li>
			<li>Rushina Parikh</li>
			<li>Somasree Choudhury</li>
			<li>Sweta Sheth</li>
			<li>Amitkumar Ghatwal</li>
			<li>Dinesh Mandrekar</li>
			<li>Sudhansu Mohanty</li>
			<li>Sagar Borse</li>
		        </ul>
            <br>
            <br> <h2>Movie Masti</h2> 
            <p style="text-align:center">  
			  <img src="files/images/brainteaser/identifymovie_oct2013.jpg" alt="Movie Masti" width="450"> 
              <br>  <br>  Identify the movie from the scene. Mail your entries to 
              <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in</a>  
            </p> <b><strong>Last quarter answer: English Vinglish  </strong>
              <br>
              <br>  <strong>Winner: Harsh Aghicha</strong>
              <br>
              <br>Other correct entries were from :
              <ul>
			<li>Yogesh Naik</li>
			<li>Pranali Mande</li>
			<li>Sairaj Kalekar</li>
			<li>Punyada Kumar</li>
			<li>Kavya Goyal</li>
 			<li>Rushina Parikh</li>
			<li>Dhruva Mistry</li>
			<li>Somasree Choudhury</li>
			<li>Bhupali Kalmegh</li>
			<li>Sweta Sheth</li>
			<li>Sonal Potnis</li>
			<li>Akshata Raikar</li>
			<li>Prachi Garaye</li>
			<li>Dinesh Mandrekar</li>
			<li>Sudhansu Mohanty</li>
			<li>Eunicia Fernandes</li>
			<li>Sagar Borse</li>
            
  		</ul>

        </div>
        <p>
          <img src="files/images/goa_newsletter_footer.jpg"/>
        </p>        
      </div>                                              	                                                                                    
                                              
    <div id="footer">                                                          
      <p>Copyright &copy; 2013 Persistent Systems Ltd.                                                  
      </p>                                                             
    </div>              
    </div>                                              
  </body>
</html>