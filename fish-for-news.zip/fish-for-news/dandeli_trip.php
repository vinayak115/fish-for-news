<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>  
<style>
#content {
    line-height: 18px;
    text-align: justify;
}
</style>	
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                                                             
                    <ul>           		  
                        <li class="menuitem">
                            <a href=".">Home</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="technobyte.php">Techno Byte</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="Happenings/prerana.html">Happenings</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="framed.php">Framed</a>
                        </li>           		  
                        <li class="selected">
                            Kaleidoscope
                        </li>  		  
                        <li class="menuitemn">
                            <a href="didyouknow.php">Viva Goem</a>
                        </li>         
                        <li class="menuitem">
                            <a href="contactUs.php">Contact Us</a>
                        </li>                            
                    </ul>                                           
                </div>    
        <div id="submenu">
        <ul>
        
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>		
		<li class="selected"><a href="javascript:void(0)">Dandeli- Into the Wild</a></li>		
        </ul>
        </div>             
        <div id="content">
          <h1>
           Dandeli....into the wild
          </h1>
          <p>
			I always admire nature for its marvelous creations. I don&rsquo;t read books on nature nor do I study the genetic structure of chloroplast. But it is simpler to admire it and pretend to be Bear Grylls. To be in the wild and amongst the beauty of it, I joined my office-mates on a trip to Dandeli as we could engage ourselves in white water rafting on river Kali. We set off from Goa, a warm evening on a 1948 cc, 15 seater desi limo to Dandeli , for those wondering where this could be,its Karnataka. Since I knew the local language (kannada) spoken there, I was chosen as the Supreme Commander for food and shelter arrangement for my army . I had booked a guest house, Dandeli Nisarga, on the net. They had offered us breakfast, lunch, dinner, a camp fire, a trek and of course the rooms for around Rs.750 per person! Considering these fantastic rate , many a times during the journey, the only doubt that lingered in my mind was whether the guest house actually existed! However chose not to reveal this suspicion to anyone. 
          </p>
          <p>
After 4 hours of our journey through towns and villages, we entered a wild forest area. We traveled further for another 30 minutes and the roads seemed very similar to the ones we had just left behind. What kept me wondering was,were we traveling in circles? "No" I told myself and wished every few signboards that we came across was a Google map. There was no cell phone range and none of the signboards mentioned Dandeli. As though rescue was just around, we entered a town from where we were directed to Dandeli and finally  found our guest house, Dandeli Nisarga. It was 10pm when we reached and the whole guest house was in darkness. There was no electricity! Aha!! so this is why the offer was made cheap. They did not have electricity, I did not ask about it and they did not tell me! 
		  </p>
		  
		  <p>The owner (and manager) assured me (in Kannada) that the electricity supply would resume as there was a power cut in the area. He was rubbing his chin, his voice seemed doubtful and his body language indicated he was not sure!!  I noticed all this and assured that all was well to my friends , of course, confidently. We all proceeded for dinner as I covertly checked whether the rooms had any switch boards. Yes they did! There were tube lights and fans too! My James Bond mode switched off when the tube lights lit up and the owners assurance turned out to be true. After a delicious dinner, we sat by the camp fire and went off to sleep at around 2am.
		  </p>		  
		  
		  <p style="text-align:center;">
             <img src="files/images/dandeli_river.jpg">
			 <br><strong>River Kali in Dandeli, Karnataka.</strong>
		  </p>		  
		 
		  <p>We chose not to go trekking the next morning and headed straight to the river rafting destination. It was Holi on that day and to our surprise we met a  bunch of multicolored kids  who blocked  the road with bamboo sticks and threw colored powder. We reacted instantly by closing all the windows as if chemical weapons were being hurled at us. The driver was kind enough to get colored all over his face on our behalf . After a 30 min drive, we reached river Kali. I was amazed by the serenity and the calmness of the river. We hired 2 rafts that woulkd accommodate 15 of us. We were provided with head gears and life jackets. The rafting experts who accompanied us on the raft instructed us on how to row a raft and how to handle it. He told us to stay calm if at all we fell in the river while rafting. In order to demonstrate this ,after we rowed away from the shore, he instructed us to get into the water as if he were telling this to a bunch of Olympic swimmers. We were dumbstruck!!  I wasn&rsquo;t scared of the water but just a bit nervous about the river being deep and dark green. Allow me to present my theory on the color of water.</p>		  
          
		  <p>
            <strong>Blue water = Beach + crabs + weeds which feel like snakes +  shells that  you want to take home.</strong>
			<br>
			<strong>Green water = Large hungry crocodiles</strong>
			<br>
			<strong>Green water + humans = Excited crocodiles + A happy meal</strong>
          </p>
		 
          <p>
            I had to forget this theory for a while just to  look macho , so jumped into the water with my life jacket on. I sensed a moment  of drowning initially but let go of all the nervousness and just laid with my back on the water. The climate was cool as I felt the breeze over my face. The blue sky spread above me and I could hear the wild birds in the forest surrounding the river. It seemed so effortless to stay on water. After swimming a bit , I climbed back on the raft. As I getting ready for the 9 kms of river rafting that lay ahead, I casually asked the instructor whether there were any crocodiles in the water. And to my disbelief he answered "Yes"!! WOW !! that was so honest of him! my theory was thus proved right. To calm us down a little the instructor told us that the crocodiles were &lsquo;vegetarian&rsquo; and had not harmed any humans in the river till now.
		  </p>
			
		<p>
            With a proud feeling of having &lsquo;swam&rsquo; in a river infested with crocodiles I rowed along with the others towards the first of the six rapids in the river. Rapids are caused due to obstruction in the downstream flow of the river creating a miniature water fall. The first rapid was enormous,it flung us with the water flow and we were all drenched in seconds.			
		<p>
		<p style="text-align:center;"><img src="files/images/dandeli_river-2.jpg" />
		<br><strong>The first rapid in the river.</strong></p>
		
        <p>	The next six or so rapids brought the navy seals out of us ! A few on the other boat fell into the water only to return back and row further. It was a memorable 1.5 hour journey through the river. We rowed through narrow tunnels formed by dense bushes that  made an arc like structure over the water. I was in love with nature and being a rafting instructor felt like the best job in the world. Away from the busy streets and the polluted cities right in the heart of the nature, this experience was really breathtaking. We rowed through all the rapids and were asking for more at the end of the activity.</p>
<p style="text-align:center;"><img src="files/images/rafting.jpg" /><br><strong>The thrills of white water rafting!</strong></p>		
			
		 <p>
            Once we reached Dandeli Nisarga we revealed the Holi colors that some of us had smuggled without the knowledge of the others and thus it was emptied  on each other. RGB was everywhere, on shirts and on faces. The threads of colors weaved themselves through the crisp afternoon air.			
		 </p>
		 
		<p style="text-align:center;"><img src="files/images/dandeli_color.jpg" />
		<br><strong>RGB on our face and shirts</strong></p>		 
		
		<p>
           After a refreshing bath and a superb lunch, the soothing weather laid everyone off to sleep. As the evening started blending with the late afternoon we packed up for our journey back home. We  left the wilderness behind as our vehicle drove over the muddy roads through the jungle. </p>
		   <p style="text-align:center;"><img src="files/images/dandeli_group.jpg" />
		   <br><strong>Us, at Dandeli</strong></p>
		   <p>With pleasant memories we woke up the next morning and met each other at work to discuss the amazing trip. Truly, nature has its own creations which man will never be able to create.
		</p>
		
		<p> &nbsp; </p>
		<p> &nbsp; </p>
		  
		  
        </div>
<p><img src="files/images/nikhil-bhat-footer.jpg"/></p>

   
                                       
      </div>
      <div id="footer">
<p>
Copyright &copy; 2013 Persistent Systems Ltd.              </p>
        </div>        
    </div>  
  </body>
</html>