<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" /> 
        </div>                
       <div id="menu">                                                             
                    <ul>           		  
                        <li class="menuitem">
                            <a href=".">Home</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="technobyte.php">Techno Byte</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="Happenings/prerana.html">Happenings</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="framed.php">Framed</a>
                        </li>           		  
                        <li class="selected">
                            Kaleidoscope
                        </li>  		  
                        <li class="menuitemn">
                            <a href="didyouknow.php">Viva Goem</a>
                        </li>         
                        <li class="menuitem">
                            <a href="contactUs.php">Contact Us</a>
                        </li>                            
                    </ul>                                           
                </div>   
        <div id="submenu">
        <ul>
        
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="selected"><a href="#">Where in the world</a></li>
        	<li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>
		
		</ul>
        </div>             
        <div id="content">
<h2 class="page-title">Where in the World</h2>



<p align="center" style="text-align: center">
<img src="files/images/whereintheworld/whereintheworld.jpg" width="550"/>
</p>
      <p>
<br/>
<p style="text-align:justify;">
This festival is mostly welcomed in the month of March to early May. Within these months many festive celebrations are held all across this county. It&rsquo;s a deep tradition celebrated by every person in this country with their families, co-worker and friends. Also known as Hanami in the local language, it&rsquo;s a delightful sight enjoying the beauty of these flowers. Many decorative electric lanterns are hung in the trees for evening enjoyment. 
</p>


<p>Name this festival and the country where you would mostly enjoy it. Send in your entries to  <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in</a>
</p>

<p><b>Last Quarter's answer was : It was the Mexican dish, Taco
</b></p>

<p><strong>Winner : Meryl Fernandes
</strong></p>

<p>
<b>Other Correct entries were from :</b>
<ul>
<li>Mittal Saglani</li>
<li>Harsh Aghicha</li>
<li>Vivek Sawant</li>
<li>Rushina Parikh</li>
<li>Kavya Goyal</li>
<li>Ravindra Dashputre</li>
<li>Varsha Gadekar</li>
<li>Dhruva Mistry</li>
<li>Sanat Keni</li>
<li>Valencia Fernandes</li> 
<li>Shardul Kalwit</li> 
<li>Swapnil Konkankar</li> 
<li>Ameya Prabhudessai</li> 
<li>Eunicia Fernandes</li> 
</ul>
</p>
   
</div>	    <img src="files/images/goa_newsletter_footer.jpg"/>                                   
      </div>
      <div id="footer">        
<p>
Copyright &copy; 2013 Persistent Systems Ltd.              </p>
        </div>        
    </div>  
  </body>
</html>
