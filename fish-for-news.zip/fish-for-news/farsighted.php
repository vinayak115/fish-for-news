<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="generator" content=
    "HTML Tidy for Windows (vers 25 March 2009), see www.w3.org" />
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>
      Goa Newletter
    </title>
    <style type="text/css">
/*<![CDATA[*/
    #content p { text-align:justify; margin: 10px;}
    /*]]>*/
    </style>
  </head>
  <body>
    <div id="outdiv">
      <div id="header">
        �
      </div>
      <div id="container">
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" />
        </div>
        <div id="menu">
          <ul>
            <li class="menuitem">
              <a href=".">Home</a>
            </li>
            <li class="menuitem">
              <a href="technobyte.php">Techno Byte</a>
            </li>
            <li class="menuitem">
              <a href="Happenings/sportsatpsl.html">Happenings</a>
            </li>
            <li class="menuitem">
              <a href="framed.php">Framed</a>
            </li>
            <li class="selected">Kaleidoscope
            </li>
            <li class="menuitemn">
              <a href="didyouknow.php">Viva Goem</a>
            </li>
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a>
            </li>
          </ul>
        </div>
        <div id="submenu">
        <ul>
	    
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="submenuitem"><a href="postcard.php">Postcard</a></li>
		<li class="selected"><a href="farsighted.php">The FARsighted</a></li>

		
		</ul>
        </div>
        <div id="content">
          <h1>
           The FARsighted
          </h1>
			<p>&ldquo;Hi! How are you? How is life?&rdquo; - I think this is the most common phrase we say when we meet someone we know! and how many times does one hear &ldquo;Life is great&rdquo; as an answer? 90% of the time we  hear people cribbing about what is &ldquo;not so good&rdquo; in life. Are most of us REALLY unhappy? or have we just learnt to focus on what is &ldquo;ONLY BAD&rdquo; in our lives? I used to do the same until something changed my perception...</p>		
			
			<p>My favorite TV soap had just begun and that followed with the almost predictable - Power cut!! Sigh! I hold on to my cell and started scrolling through the call list. I spotted a familiar name heading the &ldquo;missed calls&rdquo; list - &ldquo;Tabu - Music&rdquo; .I first met Tabu at the music class. A warm and bubbly girl with a lovely smile. One glance at her face and you couldn&rsquo;t miss those trademark specs of soda-bottle thickness. She had a blurred vision and badly needed to magnify her sight to be able to see things. Higher studies refrained me from attending my music class. I called Tabu on and off but as time passed by the frequency reduced.</p>
			<p>Today, I was surprised and nostalgic seeing her name flash in my missed call list! I called back! After about 5 mins into the conversation she mentioned that she had been abroad for a trip. I casually asked her &ldquo;So, the place must have been beautiful isn&rsquo;t it?&rdquo; To which she replied - &ldquo;Well I didn&rsquo;t actually see it! But I can tell you what I felt&rdquo;. My brain labeled this comment as &lsquo;CRYPTIC&rsquo; and sent out the default statement from my mouth - &lsquo;Eh, I didn&rsquo;t get you!&rsquo; She replied- &ldquo;I can&rsquo;t see any more. I have gone blind&rdquo; .I tried to speak but I couldn&rsquo;t hear my own voice. (I had already asked at least 10 questions by now- OMG! How??? but you could see Tabu!! how do you use your cell? can you read messages at least? are you feeling down? can anything be done about it?? - but  that was all in my mind) finally I managed to squeak an &ldquo;Oh ok! How do you manage then?&rdquo; She said &ldquo;Hey I am fine! I am doing well! I walk with a cane and yeah I don&rsquo;t wear the black specs! I hate them! And guess what, I am doing a new course which helps making software&rsquo;s compatible for use by blind people!&rdquo; Then she went on telling me about how much she enjoyed what she was doing, her new friends and how she was mastering the use of the brail script. She sounded normal! I was zapped! No hint of sorrow or self pity in her voice. </p>
			<p>I was so touched that i guess my heart just pushed these words out of my mouth - &ldquo;I am PROUD of you Tabu. Really PROUD&rdquo;. To which she replied - &ldquo;Life is once, we need to make the most of it. I just look at people who are less privileged than me and I thank God I am better off&rdquo;. After she hung up, I just lied on the couch and closed my eyes. The call had given me food for thought. Do we appreciate what we have? do we try to make the most of life? I guess the answer is NO. </p>
			<p> How painful must it be to lose something you once had and yet not crib about it? That one call taught me to appreciate life. Appreciate the people I had in my life. Today&rsquo;s day life is so fragile that you don&rsquo;t know whether you will see a friend or family member the next day! So why create tensions, why see only the bad side of things why not make the most of what we have.  </p>
		
			<p> I would not call Tabu blind because she HAS VISION. She has the power to &ldquo;See&rdquo; what is important in life. In a way, most of us are blind.So lets learn to  live life like there is no tomorrow. Value all the good things that you have around you.Don&rsquo;t waste time to say a Thank you or a Sorry! We don&rsquo;t really know if we shall be re-born do we?? ;)</p>
			<p>&nbsp;</p>
						
			<p>&nbsp;</p>
			
		  </div>
		  
		  <div style="background:#F6D797; width:755px; padding:5px 10px 5px 10px">
 					<div style="float:left;"><img src="files/images/trupti-footer.png"></div>
					<div style="float:right; padding:40px 0 0 0; width:620px; text-align:right; color:#D98700; font:bold 13px arial; margin:0; vertical-align:bottom; ">
						<em>This article is by Trupti Kakodkar, Module Lead ,  who is part of the  Rackspace team. Working with Persistent since July 2007. Trupti&rsquo;s hobbies include Reading, singing, painting and off late, - writing</em>
					</div>
					<div style="clear:both"></div>
		  </div>
				
      </div>
      <div id="footer">
        <p>
          Copyright &copy; 2012 Persistent Systems Ltd.
        </p>
      </div>
    </div>
  </body>
</html>