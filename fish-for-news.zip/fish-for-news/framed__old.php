<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/green.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/banner_green.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>
			<li class="menuitem"><a href=".">Home</a></li>
			<li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>
			<li class="menuitem"><a href="./Happenings/prerana.html">Happenings</a></li>
			<li class="selected">Framed</li>
			<li class="menuitemn"><a href="kaleidoscope.php">Kaleidoscope</a></li>
			<li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>
			<li class="menuitem"><a href="contactUs.php">Contact Us</a></li>     
          </ul>             
        </div>  
        <div id="submenu">
 <ul>                                  
            	<li class="selectedleft">                             
              		<a href="#">Framed</a>
				</li>   
			</ul>
        </div>             
        <div id="content">	                   
    
		  
		  <p><img src="files/images/framed/anupa-frame.jpg"  align="right" height="290" ><b>Name: </b>Anupa V. Narvenkar </p>
		  
		 <p align="left"><b>Education Qualification:  </b>Bachelor of Engineering in Electronics and Telecommunication and ISTQB Certified Software Tester</p>
		  
		  <p align="justify"><b>A challenging moment that you faced while at work ? </p></b>
		 <p align="left">There are many challenges that came my way but I remember this one specially, since it was critical and I was able to live up to my seniors expectations.  I had to complete the testing of one module which was given to me on the fly. I did not have any clear-cut requirements nor did I have the knowledge of the module. The development was done by the team based in US. Due to a short notice and unexpectedly short delivery time, I had to remain awake the whole night, co-ordinate with US based team and complete the testing of the module. I managed to do so successfully !</p>
		  
		 <p align="justify"><b>A software tool you would always like to work with?</b></p>
		 <p align="justify">Test Complete - Automated Software testing tool</p>

		 <p align="justify"><b>Who or what creates a strong team spirit ? </b></p>
               <p align="justify">A good leader acts as the backbone of a happy Team. He/She plays a vital role in building a good team spirit. I feel, the leader of the team should drive the team, keeping in mind the below listed factors:  </p>
	
		 <ul> <li>Positive Work Environment </li></br>
		</br><li>Build Trust</li></br>
		</br><li>A feeling of cooperation, teamwork and joy</li></br>
		</br><li>Give Recognition and Appreciation </li></br>
		</br><li>Give Credit and Take Responsibility </li></br>
		</br><li>Be Approachable to your team</li></br>
		</br><li>Make It Fun - make your workplace feel happy and festive</li></br></ul>

		<p align="justify"><b>Heading the GPC group in Goa what has been your most memorable moment so far?</b></p>
		<p align="justify">I want to take this opportunity and say proudly that, the Goa GPC team is one of the best team in PSL. I have a wonderful and talented pool of people in my team. They are very creative, innovative, very helpful and caring and most importantly everyone is willing to contribute towards this green initiative and want to do their bit for nature. Undoubtedly, the most memorable moment so far in GPC group has been the "Green Thumbs" initiative, where we perform Skits in different schools to spread awareness among children on saving our Mother Earth. This becomes an enjoyable experience for the kids as well as us, as the Skit incorporates music, dance and masti :D The instant feedback and cute reactions from the best and most unbiased judges in the world - "Children" fills my heart with a lot of joy. </p>

		<p align="justify"><b>What kind of strategies have you tried out to keep yourself successful in whatever you do?</b></p>
		 <p align="justify">I do not follow any strategies in my life. I take life as it comes to me each day!! I think, it's very important that people should realize, life is a precious gift of God and they should live it to the fullest. At the same time we should be humble, be good to everyone, respect everyone, and respect humanity. Spread the message of love and happiness across the Universe. I firmly believe that what goes around comes around. You light up people's lives and they will light up yours.</p>
		
		<p align="justify"><b>If given a chance to work onsite, say France, would you take it up? Why ?</b></p>
		 <p align="justify">Yes, of course, but only if it's for a short term. I would love to explore the new country.  But the Goenkar in me will not let me live in peace elsewhere for a longer duration.. So eventually, I  would like to return to my Goan soil.</p>

		<p align="justify"><b>What are your key assets?</b></p>
		 <p align="justify">I try my best to be a good human being and do my work with dedication and sincerity. I believe in giving my 100% in whatever I do. I believe that these assets are all I need to get closer to success. </p>

		<p align="justify"><b>Do you think your work reflects your character?</b></p>
		<p>Yes It does. I put my heart and soul in my work. It HAS to reflect my character..... shouldn't it? <img height="18" src="files/images/index.jpg"> </p>


		<p align="justify"><b>Do you think God helps those who help themselves or do you wait for a miracle?</b></p>
		 <p align="justify">I strongly believe that God helps those who help themselves. You should not wait for the opportunity, you should create the opportunity for yourself.</p>

	
		<p align="justify"><b>Quotes you live by .....</b>
		 "Live and let Live"</p>		

		</br> <p align="justify"><b>Your hobbies ? </b></p>
               <p align="justify">Ahh - I have lots of them  <img height="18" src="files/images/smile.jpg">  </p>
	
		 <ul> <li>Participating in Social awareness programs </li></br>
		</br><li>To Compere Stage shows</li></br>
		</br><li>Acting</li></br>
		</br><li>Playing Musical Instruments - Tabla, Ghumat, Keyboard and Guitar. </li></br>
		</br><li>Singing, Dancing </li></br>
		</br><li>Playing Cricket and Badminton</li></br></ul>
		
		

		<p align="justify"><b>Wish You'll a very happy and prosperous New Year. <img height="18" src="files/images/smile.jpg"> </b> </p>


	  
		  
        </div>	
		<img src="framed-foo.JPG" class="signature"/> 
      </div>

      <div id="footer">                                                 
        <p>Copyright &copy; 2013 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>        
    </div>  
  </body>
</html>