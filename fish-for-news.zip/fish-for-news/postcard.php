<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="generator" content=
    "HTML Tidy for Windows (vers 25 March 2009), see www.w3.org" />
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>
      Goa Newletter
    </title>
    <style type="text/css">
/*<![CDATA[*/
    #content p { text-align:justify; margin: 10px;}
    /*]]>*/
    </style>
  </head>
  <body>
    <div id="outdiv">
      <div id="header">
        �
      </div>
      <div id="container">
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" />
        </div>
        <div id="menu">
          <ul>
            <li class="menuitem">
              <a href=".">Home</a>
            </li>
            <li class="menuitem">
              <a href="technobyte.php">Techno Byte</a>
            </li>
            <li class="menuitem">
              <a href="Happenings/sportsatpsl.html">Happenings</a>
            </li>
            <li class="menuitem">
              <a href="framed.php">Framed</a>
            </li>
            <li class="selected">Kaleidoscope
            </li>
            <li class="menuitemn">
              <a href="didyouknow.php">Viva Goem</a>
            </li>
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a>
            </li>
          </ul>
        </div>
        <div id="submenu">
        <ul>
	    
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="selected"><a href="#">Postcard</a></li>
		<li class="submenuitem"><a href="farsighted.php">The FARsighted</a></li>

		
		</ul>
        </div>
        <div id="content">
          <h1>
           Postcard 
          </h1>
			<p>!!   Shimla  -  Manali  - Chandigarh  !!</p>		
			<img height="300" style="float: right; margin-left: 15px; margin-bottom: 5px;"  alt="" src="files/images/postcard/namrata1.jpg"><br>
			<p>There  are  times  when  you  just  want  to go  some where, away from work , from the place you stay , away from normal routine . That&rsquo;s when you realise where you want to go, on a tour !! </p>
			<p>We had covered most of the places in South of India , so this time we decided  to go  to Himachal Pradesh. We began the hunt through the various itineraries of different tour organisers. Mind you they lie e a lot ! Experience has taught me that the  cost saver packages they have to offer actually turns out to be your most expensive  tour  . Finally it was Yatrik travels, we heard about it  from one of our family friends and found its rates pretty reasonable  .You can visit their sight for tour details at   http://www.yatriktravels.com/ .</p>
			<p>We decided on the Shimla - Manali - Chandigarh tour package,   total 10 days .  The tour started from Delhi,  very early, at about 5 am, by Volvo Bus, with 5 families , 1 sardarji driver , 1 cleaner , and two coordinators from Yatrik travels.  We were very lucky to  have quick bonding people amidst  us . It took us no time to introduce each other and within few hours we were all seated in seats which were not allotted to us  , playing Antakshari , some word games etc.  </p>
			<p>Along the way to Chandigarh, we stopped by a typical dhaba to enjoy our breakfast. Please allow me to describe just this one breakfast,it was my favourite !!. It was a typical Dhaba , with trucks parked at the entrance, some wooden furniture around , and THE CHEFS, outdoor, making parathas , tandoor stuff , jalebis  , lasssi etc. We ordered for this beautiful  lasssi... ya, ya it was beautiful, rich and creamy !  It was then followed by  potato , onion , cabbage parathas  which were accompanied with pickle , dahi  and   &lsquo;makhan&rsquo;.. not butter. Makhan is a desi butter and it tastes  way better then amul butter ! The satisfactory feeling you get after having this Punjabi breakfast is unimaginable. ? Once done with this , we were on our way. </p>
			<img width="300" style="float: left; margin-right: 15px;" alt="" src="files/images/postcard/namrata2.jpg"><br>
			<p>As you approach Shimla, and are a few km from it , the city is  ready to welcome you with a pleasant, cool weather , awesome sceneries  , beautiful vegetation and people . The weather was  breezy with a few drizzles here and there ! Once on reaching the hotel, we  were all tired and wrapped ourselves in warm blankets in our rooms . The next day, the  temperature  was super cold, that&rsquo;s  when we went to see the valley.  From there it was a visit to the famous Church and Lakkad bazaar. By afternoon the climate was pretty pleasant. In the evening  we went for horse riding on the hills. I wanted a white horse , but the  guide  was persuading me to have a ride on this brown coloured horse.  I had to go uphill on that horse , who turned out to be the very excited kinds.  I was the last when I started off however when we reached  on top of the hill , I was the second . I must have yelled so many times at the  guide  , to control his so called best horse , but he was laughing at me saying that you have paid me for a walking ride and I m giving you running horse at the same rate .  Thankfully they changed the horses when we came downhill that&rsquo;s when I got the white horse !!! He was very sweet and maintained  his speed through out ! I liked it :) </p>
			<p>Next day , we travelled towards Manali. Manali is less cooler then Shimla  and has awesome river  view sceneries.   The hotel in which we checked in had a eye pleasing view from our rooms. Those tall deodhar trees standing right there , with hills behind  wearing snow caps. Beautiful ! . Next morning,  the coordinator told us there were some ladies in the back garden with these huge rabbits and some costumes of Himachals. We all rushed  to see these rabbits, they  were too cute , huge in size , full of fur and were very much scared . Everyone wanted rabbits in their arms  to click some photos. We then tried out their costumes, no one hesitated so we stood there,&lsquo;bindaas&rsquo; and  gave some really nice poses to all photographers.  From there , it was time to visit Hidimba temple , rested right in the middle of deodhar forest , which was located very close to our hotel.</p>
			<img width="300" style="float: left; margin-right: 15px;" alt="" src="files/images/postcard/namrata3.jpg"><br>
			<p> The day came to the end, night rolled in, the new day was going to be one of the best day ! We went river rafting. It was the first time for me ! Initially we were around 5 youngsters who had given our names later a couple from our group aging 75 gave in their names, left me pretty shocked on seeing the enthusiasm.    The boring part was travelling 45 min to the spot where river rafting actually begins. Once we reached  the spot, we met our instructors, who provided us with life jackets and explained us some simple rules.  The instructor handed me the oar and told me to sit right in front! I touched the transparent river water, it was icy cold !! Our instructor took care that none of the members were left out dry, every time the chilled water splashed on my face , I wanted it more . It was a 15km journey. We were singing songs, some slogans , the entire ride was indeed very memorable .We also visited the Gurudwara, the place of worship for Sikhs.  Later we enjoyed  the       Vanabhojan ( having lunch in forest ). It was a river side view , tall trees surrounding and the amazing garam garam Mumbai paav bhaaji :)  . Later it was time for a little shopping, we did a bit of shopping in Manali that evening. </p>
			<img width="300" style="float: right; margin-left: 15px; margin-bottom: 5px;" alt="" src="files/images/postcard/namrata4.jpg"><br>
			<p> Next day we got up vey early to go to snow point at Rohtang Pass. All these days we were able to see snow from a distance ,on hills far away ,today, we were going to play with it ! I always find journeys to such exciting places unending. On reaching the spot we faced a  traffic jam. We walked a bit ... cross a small stream and there we were, finally on our feet on the snow ! I don&rsquo;t even remember how long we were playing . No one bothered to look at the time, we realised it was time up only when the coordinator came to remind us that we have to go back . The moment we reached Hotel, all fell asleep and got up late in the evening. We dint go anywhere that day . At night  we were all set to rock  the discotheque . Our journey was coming to an end, it was time to leave Manali and head to Chandigarh. In Chandigarh we went to the rock garden and visited a lake. The funny part of the lake was , its name, it  was called  &lsquo;Sukhna&rsquo; Lake(which means doesn&rsquo;t dry in konknai atleast ) but sadly that lake was &lsquo;sukillo&rsquo;(dried out). :D </p>
			<p>When the last day came , to our surprise, the excitement had not dried out at all. Full day we sang songs in the bus, did mimicry of people , we were not ready to leave the mike.  We dint want it to end so we decided till we reach Delhi we won&rsquo;t stop. After all song from Bollywood got over , we started with nursery rhymes . Yes , followed by aartis which we say for Ganesh Chaturthi. And the bus stopped exactly when we ended with &lsquo;Ghalin Lotangan&rsquo; :D </p>
			<p>&nbsp;</p>
						
			<p>&nbsp;</p>
			
		  </div>

		<div style="background:#F6D797; width:755px; padding:5px 10px 5px 10px">
 					<div style="float:left;"><img src="files/images/namrata-footer.png"></div>
					<div style="float:right; padding:40px 0 0 0; width:620px; text-align:right; color:#D98700; font:bold 13px arial; margin:0; vertical-align:bottom; ">
						<em>This article is by Namrata Khandeparkar, Senior Software Engineer ,  who is part of the  United Sample Team , working with Persistent since Dec 2010. Namrata's hobbies include reading , blogging and listening to music</em>
					</div>
					<div style="clear:both"></div>
		  </div>
      </div>
      <div id="footer">
        <p>
          Copyright &copy; 2012 Persistent Systems Ltd.
        </p>
      </div>
    </div>
  </body>
</html>