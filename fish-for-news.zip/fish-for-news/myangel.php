<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
        <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
        <title>Goa Newletter
        </title>
    </head>
    <body>
        <div id="outdiv">
            <div id="header">           &nbsp;
            </div>
            <div id="container">
                <div id="banner">
                    <img src="files/images/orange/banner.jpg" alt="banner" />
                </div>
        <div id="menu">
         <ul>
            <li class="menuitem"><a href="index.php">Home</a></li>
            <li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>
            <li class="menuitem"><a href="Happenings/sportsatpsl.html">Happenings</a></li>
            <li class="menuitem"><a href="framed.php">Framed</a></li>
            <li class="selected">Kaleidoscope</li>
            <li class="menuitemn"><a href="didyouknow.php">Viva Goem</a></li>
            <li class="menuitem"><a href="contactUs.php">Contact Us</a></li>
          </ul>
        </div>
                 <div id="submenu">
        <ul>
       <li class="left"><a href="kaleidoscope.php">Talent Museum</a></li>
		<li class="submenuitem"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem" ><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="selected"><a href="#">My Angel</a></li>
		<li class="submenuitem"><a href="specialdedication.php">Special Dedication</a></li>
        </ul>
        </div>    

    <div id="content" style="margin:0;">
	<p>	<img src="files/images/my_angel.jpg"> </p>		
	</div>
  <!--<img class="signature" src="files/images/footer-namrata.jpg">-->
 </div> 

      <div id="footer">
        <p>Copyright &copy; 2012 Persistent Systems Ltd.
        </p>
      </div>

        </div>


    </body>
</html>