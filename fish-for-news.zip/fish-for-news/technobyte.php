<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/violet_css.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>  
<style>
#content {
    line-height: 18px;
    text-align: justify;
	padding:5px;
}
#rgb td{
padding:5px;
text-align:center;
}
</style>	
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/purple_banner.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>          
            <li class="menuitem"><a href=".">Home</a></li>          
            <li class="selected">Techno Byte</li>          
            <li class="menuitemn"><a href="./Happenings/sportsatpsl.html">Happenings</a></acronym></li>          
            <li class="menuitem"><a href="framed.php">Framed</a></li>          
            <li class="menuitem"><a href="kaleidoscope.php">Kaleidoscope</a></li>    
            <li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>        
            <li class="menuitem"><a href="contactUs.php">Contact Us</a></li>                 
          </ul>             
       </div>  
        <div id="submenu">
         <ul>                                  
			  <li class="submenuitem selected"><a href="technobyte.php"><b>Cellular Technology</b></a></li>                       
              <li class="submenuitem "><a href="technobyte1.php"><b>NodeJS</b></a></li>                 
          </ul>   
        </div>                       
                <div id="content">	 
				<br>
	<div id="poq-content">  
    <h2 class="page-title">Cellular Technology</h2>    
	
	<p align="justify">Today cell phones have taken over our world. You forget your mobile phone at home and it gives an impression that you are missing something really important. Communication is the key to the success of a society and understandably. How often though have you looked at your phone wondering how on earth it all comes together? How can you make calls just by the press of a button? The text below aims to give you a brief understanding of this technology. Though today's technology is much more advanced, this could be considered as a starter.</p>
	<p align="justify">A mobile phone is a really complex radio. A radio uses a single modulated frequency to communicate. Modulation in layman terms is changing a property (amplitude, frequency etc.) of the data signal using a carrier. For example, in commercial FM, the frequency of the audio signal (data or baseband) is changed in accordance with the carrier frequency. The carrier frequency is generally much higher than data frequency. The higher the frequency being transmitted the lower the antenna length required. Therefore, our mobiles have small antennas. That is the fundamental behind modulating the data signal. Now coming back to the radio. </p>
	<p align="justify">Since the radio uses just a single frequency or channel for communication, data can be sent only in one direction at a given instance of time so only one person can speak in a conversation at a given instance. This is known as half-duplex communication. The world soon realized that it was electronically unviable to have a single unique frequency per radio pair to prevent signal interference also the power required to establish and maintain communication was too high. This is where cellular technology came in. </p>
	<p align="justify">Cellular technology uses a network of towers that help establish a communication channel between two parties using their cell phone. The genius of the cellular system is the division of a city into small cells. This allows extensive frequency reuse across a city, so that millions of people can use cell phones simultaneously. The use of towers meant that the power that needed to be transmitted was also considerably lesser and the distance over which a user could continue a conversation without interference was much larger.</p>
	<p align="justify">In a typical analog cell-phone system, the cell-phone carrier receives about 800 frequencies to use across the city. The carrier chops up the city into cells. Each cell is typically sized at about 10 square miles (26 square kilometers). Cells are normally thought of as hexagons on a big hexagonal grid as shown in Figure 1.</p>
	<p align="center"><img src="files/images/technobyte/shaunak1.JPG" class="signature"/> </p>
	
	<p align="justify">Since the cellphones and towers use low power frequencies, the same frequency can be reused in non-adjacent cells. For example, in Figure 1 the two purple cells use the frequency without any interference.</p>
	<p align="justify">A typical analog cell phone system gets around 832 radio frequencies to use in a given city. To establish a full-duplex communication a cell phone uses two of these frequencies (one to transmit and the other to receive simultaneously) per call. The cellular system also uses control channels over which voice data cannot be transmitted. These are reserved for specific data only. There are 42 such channels. This reduces the number of usable channels per city to 790</p>
	<p align="center">Maximum Voice Channels = 790 / 2 = 395</p>
	<p align="justify">Each cell within a city uses 1/7th of the maximum voice channels available for the city in order to prevent interference through frequency reuse. This is obvious from the fact that each hexagonal cell share an edge with six other hexagonal cells so any cell could therefore use 6 + 1 voice channels of the cellular system at a given instance of time. This reduces the maximum number of simultaneous calls that can be made in a cell to </p>
	<p align="center">Maximum voice calls per cell = 395 / 7 = 56</p>
	<p align="justify">To prevent frequency interference each tower and mobile phone pair transmit at low power and this allows our mobile phone to be powered by just a small battery and last us for a day.</p>
	<p align="justify">The cellular approach requires a large number of base stations in a city of any size. A typical large city can have hundreds of towers. But because so many people are using cell phones, costs remain low per user. Each carrier in each city also runs one central office called the Mobile Telephone Switching Office (MTSO). This office handles all of the phone connections to the normal land-based phone system, and controls all of the base stations in the region.</p>
	<p align="justify"><b>When you receive or make a call</b></p>
	<p align="justify">All cell phone have unique codes associated with them (see Table 1). These codes are used to identify the phone, the phone's owner and the service provider. Let's say you turn on your cell phone and someone tries to call you.</p>

	<!-- Javascript goes in the document HEAD -->
<script type="text/javascript">
function altRows(id){
	if(document.getElementsByTagName){  
		
		var table = document.getElementById(id);  
		var rows = table.getElementsByTagName("tr"); 
		 
		for(i = 0; i < rows.length; i++){          
			if(i % 2 == 0){
				rows[i].className = "evenrowcolor";
			}else{
				rows[i].className = "oddrowcolor";
			}      
		}
	}
}
window.onload=function(){
	altRows('alternatecolor');
}
</script>

<!-- CSS goes in the document HEAD or added to your external stylesheet -->
<style type="text/css">
table.altrowstable {
	font-family: Arial,Helvetica,sans-serif;
	font-size:11px;
	color:#333333;
	border-width: 1px;
	border-color: #a9c6c9;
	border-collapse: collapse;
}
table.altrowstable th {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #a9c6c9;
}
table.altrowstable td {
	border-width: 1px;
	padding: 8px;
	border-style: solid;
	border-color: #a9c6c9;
}
.oddrowcolor{
	background-color:#d4e3e5;
}
.evenrowcolor{
	background-color:#c3dde0;
}
</style>

<!-- Table goes in the document BODY -->
<table class="altrowstable" id="alternatecolor" align="center">
<tr>
	<th>Cell Phone Code</th><th>Description</th></tr>
<tr>
	<td>Electronic Serial Number (ESN)</td><td>a unique 32-bit number programmed into the phone when it is manufactured</td></tr>
<tr>
	<td>Mobile Identification Number (MIN)</td><td>a 10-digit number derived from your phone's number</td></tr>
</tr>
<tr>
	<td>System Identification Code (SID)</td><td>a unique 15-bit number that is assigned to each carrier by the FCC (regulatory body in the US)</td></tr>

</table>

<!--  The table code can be found here: http://www.textfixer/resources/css-tables.php#css-table03 -->
<p align="center"> Table 1: List of Cell Phone Codes</p>
	<p align="justify">
	<ul>
	<li>Your phone listens for an SID  on the control channel. The control channel is a special frequency that the phone and tower or base station use to talk to one another about things like call set-up and channel changing. If the phone cannot find any control channels to listen to, it knows it is out of range and displays a "no service" message.</li>
	<li>When it receives the SID, the phone compares it to the SID programmed into the phone. If the SIDs match, the phone knows that the cell it is communicating with is part of its home system.</li>
	<li>Along with the SID, the phone also transmits a registration request, and the MTSO keeps track of your phone's location in a database; this way, the MTSO knows which cell you are in when it wants to ring your phone.</li>
	<li>The MTSO gets the call, and it tries to find you. It looks in its database to see which cell you are in.</li>
	<li>The MTSO picks a frequency pair that your phone will use in that cell to take the call.</li>
	<li>The MTSO communicates with your phone over the control channel to tell it which frequencies to use, and once your phone and the tower switch on those frequencies, the call is connected. Now, you are talking by two-way radio to a friend.</li>
	<li>As you move toward the edge of your cell, your cell's base station notes that your signal strength is diminishing. Meanwhile, the base station in the cell you are moving toward (which is listening and measuring signal strength on all frequencies, not just its own one-seventh) sees your phone's signal strength increasing. The two base stations coordinate with each other through the MTSO, and at some point, your phone gets a signal on a control channel telling it to change frequencies. This hand off switches your phone to the new cell.</li>
	</ul>

	</p>
	<p align="justify">Let's say you're on the phone and you move from one cell to another; but the cell you move into is covered by another service provider, not yours. Instead of dropping the call, it will actually be handed off to the other service provider. If the SID on the control channel does not match the SID programmed into your phone, then the phone knows it is roaming. The MTSO of the cell that you are roaming in contacts the MTSO of your home system, which then checks its database to confirm that the SID of the phone you are using is valid. Your home system verifies your phone to the local MTSO, which then tracks your phone as you move through its cells.</p>
	<p align="justify">I hope the text has been enjoyable and has given you an insight into the technology that has changed today's world and really, we all cannot do without.</p>

	</div>
	</div>	
	
		<img src="files/images/technobyte/shaunak_footer.jpg" class="signature"/> 
    	</div>
      	                                       
     
      <div id="footer">                        
        <p>Copyright &copy; 2013 Persistent Systems Ltd.                  
        </p>                                     
      </div>       
    </div>  
  </body>
</html>
