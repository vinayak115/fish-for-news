<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />       

<script language="javascript">
function showsubtab1(){

div1 = document.getElementById('subtab1');
div2 = document.getElementById('subtab2');
div3 = document.getElementById('subtab3');
div4 = document.getElementById('subtab4');

div2.style.display = "none";
div3.style.display = "none";
div4.style.display = "none";
div1.style.display = "block";

var menu = document.getElementById('submenu2');
menu.style.display = "none";

var parent = document.getElementById('submenu1');
var element1 = parent.getElementsByTagName('li')[0];
var element2 = parent.getElementsByTagName('li')[1];

element1.className = "submenuitem selected";
element2.className = "submenuitem";

}

function showSubTAb2(){

div1 = document.getElementById('subtab1');
div2 = document.getElementById('subtab2');
div3 = document.getElementById('subtab3');
div4 = document.getElementById('subtab4');

div1.style.display = "none";
div2.style.display = "block";
div3.style.display = "none";
div4.style.display = "none";

var menu = document.getElementById('submenu2');
menu.style.display = "block";

var parent = document.getElementById('submenu1');
var element1 = parent.getElementsByTagName('li')[0];
var element2 = parent.getElementsByTagName('li')[1];

element1.className = "submenuitem";
element2.className = "submenuitem selected";

}

function showSubTAb3(){

div1 = document.getElementById('subtab1');
div2 = document.getElementById('subtab2');
div3 = document.getElementById('subtab3');
div4 = document.getElementById('subtab4');

div1.style.display = "none";
div2.style.display = "none";
div3.style.display = "block";
div4.style.display = "none";



var menu = document.getElementById('submenu1');

menu = document.getElementById('submenu2');
menu.style.display = "block";

var parent = document.getElementById('submenu1');
var element1 = parent.getElementsByTagName('li')[0];
var element2 = parent.getElementsByTagName('li')[1];

element1.className = "submenuitem";
element2.className = "submenuitem selected";

}

function showSubTAb4(){

div1 = document.getElementById('subtab1');
div2 = document.getElementById('subtab2');
div3 = document.getElementById('subtab3');
div4 = document.getElementById('subtab4');

div1.style.display = "none";
div2.style.display = "none";
div3.style.display = "none";
div4.style.display = "block";

var menu = document.getElementById('submenu2');
menu.style.display = "block";

var parent = document.getElementById('submenu1');
var element1 = parent.getElementsByTagName('li')[0];
var element2 = parent.getElementsByTagName('li')[1];

element1.className = "submenuitem";
element2.className = "submenuitem selected";

}
</script>
<style>
#submenu2 {
    background-color: #FFFFFF; /*#E2E1E2;*/
    height: 24px;
    margin: 0;
}
#submenu2 ul {
    padding: 0;
    margin: 0;
}
#submenu2 ul li {
    float: left;
    list-style: none;
    padding: 3px 8px 0 8px;
}
#submenu2 ul li.submenu2item {
    background-image: url(../images/submenu1_sep.jpg);
    background-repeat: no-repeat;
    background-position: top left;
}
#submenu2 ul li.left {
}
#submenu2 ul li a {
    text-decoration: none;
    color: black;
}
#submenu2 ul li.selected {
    font-weight: bold;
    background-image: url(../images/submenu1_sep.jpg);
    background-repeat: no-repeat;
    background-position: top left;
}
#submenu2 ul li.selectedleft {
    font-weight: bold;
}
#submenu2 ul li.selected a {
    border-bottom: 1px white dotted;
}
#submenu2 ul li.selectedleft a {
    border-bottom: 1px white dotted;
}
</style>
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                                                             
                    <ul>           		  
                        <li class="menuitem">
                            <a href=".">Home</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="technobyte.php">Techno Byte</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="Happenings/prerana.html">Happenings</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="framed.php">Framed</a>
                        </li>           		  
                        <li class="selected">
                            Kaleidoscope
                        </li>  		  
                        <li class="menuitemn">
                            <a href="didyouknow.php">Viva Goem</a>
                        </li>         
                        <li class="menuitem">
                            <a href="contactUs.php">Contact Us</a>
                        </li>                            
                    </ul>                                           
                </div>    
        <div id="submenu">
        <ul>
        
		
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="selected"><a href="#">Talent Museum</a></li>
		
        </ul>
        </div>             
        <div id="content" style="margin:0;">    
<div id="submenu1">		
	 <ul>
				<li class="submenuitem selected"><a href="#" onClick="showsubtab1()">Sketches</a> &nbsp; &nbsp; | </li> 
				<li class="submenuitem"><a href="#" onClick="showSubTAb2()">Poems</a> &nbsp; &nbsp;</li>
	 </ul>
 </div>
 
 <div id="submenu2" style="display:none;">		
	 <ul>
				
				<li class="submenuitem"><a href="#" onClick="showSubTAb2()">Nase Parat Ekda</a> &nbsp; &nbsp; | </li>
				<li class="submenuitem"><a href="#" onClick="showSubTAb3()">Kadhi Aamhi</a> &nbsp; &nbsp; | </li>
				<li class="submenuitem"><a href="#" onClick="showSubTAb4()">Maagan</a></li>
	 </ul>
 </div>
 
 
 
<div id="subtab1" >
<!--<h2 class="page-title">Gods garden</h2>-->
<p style="text-align:center"><img alt="poem" src="files/images/talentmuseum/sketches.jpg" width="776"></p>
<br>
</div>


<div id="subtab2" style="display:none;">
<!--<h2 class="page-title">Rain</h2>-->
<p style="text-align:center"><img alt="poem" src="files/images/talentmuseum/poem1.jpg" width = "776"></p>
<br>
</div>
  
<div id="subtab3" style="display:none;">
<!--<h2 class="page-title">Prem</h2>-->
<p style="text-align:center"><img alt="poem" src="files/images/talentmuseum/poem2.jpg" width = "776"></p>
<br>
</div>


<div id="subtab4" style="display:none;">
<!--<h2 class="page-title">Prem</h2>-->
<p style="text-align:center"><img alt="poem" src="files/images/talentmuseum/poem3.jpg" width = "776"></p>
<br>
</div>

</div>


</div>	

     <div id="footer">
<p>
Copyright &copy; 2013 Persistent Systems Ltd.              </p>
        </div>    
   
                                       
      </div>
     
    </div>  
  </body>
</html>