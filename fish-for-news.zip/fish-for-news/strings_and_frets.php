<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>  
<style>
#content {
    line-height: 18px;
    text-align: justify;
}
</style>	
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                                                             
                    <ul>           		  
                        <li class="menuitem">
                            <a href=".">Home</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="technobyte.php">Techno Byte</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="Happenings/prerana.html">Happenings</a>
                        </li>           		  
                        <li class="menuitem">
                            <a href="framed.php">Framed</a>
                        </li>           		  
                        <li class="selected">
                            Kaleidoscope
                        </li>  		  
                        <li class="menuitemn">
                            <a href="didyouknow.php">Viva Goem</a>
                        </li>         
                        <li class="menuitem">
                            <a href="contactUs.php">Contact Us</a>
                        </li>                            
                    </ul>                                           
                </div>    
        <div id="submenu">
        <ul>
        
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>		
		<li class="selected"><a href="javascript:void(0)">Strings And Frets</a></li>		
        </ul>
        </div>             
        <div id="content">
          <h1>Strings And Frets</h1>
          <p>
			Vacations are those times when you get to set loose all those supposedly life changing, miraculous thoughts that peck your mind while studying for exams. As for myself, my motivational spirits fly higher than Superman ever would, to do all other activities except studies during the study holidays just before exams. However my laziness weighs heavier than me, so I end up carrying it through the holidays, unable to implement all those ideas and leave them to haunt me during the next study holidays.
          </p>
		  
          <p>On one such vacation from my gruelling engineering studies, I decided to learn to play a guitar. Most of the people I have met in life want to learn a guitar because it&rsquo;s cool. I wanted to learn a guitar because...yes it was cool !!. All I wanted to do was to be able to sing a song as I played the guitar. As simple as that! So  the strumming of the strings, playing the electrifying lead and shouting "Do you want more ?" to my thousands of imaginary fans, compelled me to join a crash course in learning to play the coolest musical instrument.
		  </p>
		  
		  <p>After joining the class and justifying it as "my strong interest" at home, I managed to borrow a guitar from a friend. On the first day of the course itself I realized that the classroom lessons were a slow motion compared to my rockstar fantasies. The first few days went in learning to play the octets. After that, the next few days went in playing the octets in the reverse order! And the strings! I knew they were made of steel, but I also discovered  that they were designed to cut through my finger tips! I had watched musicians play a guitar effortlessly  without even looking at the frets(the long bar protruding out of the curvy guitar box). And here I was,  barely able to press the strings hard!! I was a disappointment to my millions of imaginary fans. As the classes became less interesting, I decided to cut short the lessons of unknown melodies and started to practice the lead of well known Bollywood songs.I started with the notes(which I interpreted in my own way) of  "Pehla Nasha" and found it unnecessarily complicated(reality :It would take me months to play it !).So I went on to "Tujhe dekha toh yeh jaana sanam" and found it comparatively easier to play. I practiced it with all my efforts. Next day, I entered the class, sat down on the chair and played the same melody casually, as if I had learnt it by birth. As some magical powers prevented the music to reach to the ears of others around me, I did not receive the deafening applause that I expected. No one even noticed it! On one of these days, a kid, who seemed shorter than the full sized guitar he was carrying, entered the classroom and played Shakira&rsquo;s "Waka Waka" casually... casually in real. He made me realize how  "unnatural" I was in learning to play a guitar .The mistake was in my perception of  easy learning. To perfect a skill requires practice, and lots of it.
		  </p>		 		  
		 
		 <p>These classes sowed the seeds of love for music in me. After the one month crash course, I continued my practice for a short period as I had higher, less interesting priorities. However I started listening to music in a different way. I tried to comprehend the sound of every instrument in a song and tried to visualize the picture it tried to portray. Every beat and every silent note adds to the glory of a musical melody. I have developed a great ardour for music. So until my musical interests take a higher priority than my present varied ones, I continue to understand and not just listen to music and also entertain my millions of fans.</p>
		
		<p> &nbsp; </p>
		<p> &nbsp; </p>
		  
		  
        </div>
<p><img src="files/images/nikhil-bhat-footer.jpg"/></p>

   
                                       
      </div>
      <div id="footer">
<p>
Copyright &copy; 2013 Persistent Systems Ltd.              </p>
        </div>        
    </div>  
  </body>
</html>