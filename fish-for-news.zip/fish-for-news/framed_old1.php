<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/green.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/banner_green.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>
			<li class="menuitem"><a href=".">Home</a></li>
			<li class="menuitem"><a href="technobyte1.php">Techno Byte</a></li>
			<li class="menuitem"><a href="./Happenings/sportsatpsl.html">Happenings</a></li>
			<li class="selected">Framed</li>
			<li class="menuitemn"><a href="kaleidoscope.php">Kaleidoscope</a></li>
			<li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>
			<li class="menuitem"><a href="contactUs.php">Contact Us</a></li>     
          </ul>             
        </div>  
        <div id="submenu">
 <ul>                                  
            	<li class="selectedleft">                             
              		<a href="#">Framed</a>
				</li>   
			</ul>
        </div>             
        <div id="content">	                   
          <p><img src="files/images/framed/amit1.jpg" width="350" align="right" height="380" ><b>Fish-4- News team caught up with Amitkumar Ghatwal , to find out what is the latest happening in his life.</b></p>
		  
		  <p><b>Name: </b>Amitkumar Ghatwal </p>
		  
		  <p><b>Educational background: </b>B.E ( Electronics and Telecommunication)</p>
		  
		  <p><b>A learning experience you have had on this project ?</p></b>
		 <p>Got a hands on experience about graphics , touch screen library and their usage by means of developing applications using the same. </p>
		  
		  <p><b>Your goal in life ?</b></p>
		  <p  style="width:320px;text-align: justify;">Endeavour to be best at the things which I lay my hands upon. </p>

		  <p><b>2 important lessons that you always carry with you and why ?</b></p>
		  <p>Keep trying until you succeed . This keeps me focused in my day -to-day chores. 
		  Success and failures are both related. They both will happen to you someday or other , so never give up.</p>
		
		  <p><b>Lets assume you have assigned a task to your subordinate who doesn't deliver on time, what would you do ?</b></p>
                <p>Would like to sit with him/her and try and sort out issues with regard to the task with me just playing the mentor role. </p>
			 
		  
		  <p><b>If not a software engineer what would you have been ?</b></p>
		  <p style="text-align: justify;">Would have loved to serve Indian armed forces.</p>
		  
		  <p><b>Your favorite relaxing mantra ? </b></p>
		  <p style="text-align: justify;">Live and let live ? ( Susegaad) <img height="18" src="files/images/1.gif"> </p>
		  
		  <p><b>Your favorite holiday destination and why ?</b></p>
		  <p>Kashmir. Want to ski  <img height="18" src="files/images/1.gif"></p>
		  
		 	  
		 <p><b>Your hobbies  : </b></p>
		<p>Driving , Playing badminton , movies  </p>
		  
		  <p><b>If you had to live your live again, the one thing that you would have redone ?</b></p>
		<p>Would have loved to try my luck with armed forces.</p>

		<p><b>A software tool that always interest you and why ?</b></p>
		<p>Graphics Display Designer (GDD). It saves lot of your time making graphical template ,
		and I like the idea which conceptualized such a thing . Even though it's at a niche stage ,
		would have loved to part of the design team.</p>
		
		<p><b>3 things that you are grateful for :</b></p> <p>Parents , God and mother nature. </p>

<p><b>Quotes that you live by : </b></p>
<p>Stop being a hypocrite , be yourself ! <br>
Be satisfied with what you have ... <br>
Everything is written in your destiny ... you can't change it.</p>

		
		
		  
		  
        </div>	
		<img src="files/images/framed/framed-foo_yogesh.jpg" class="signature"/> 
      </div>

      <div id="footer">                                                 
        <p>Copyright &copy; 2012 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>        
    </div>  
  </body>
</html>ss