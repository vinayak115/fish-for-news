<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/green.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/banner_green.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>
			<li class="menuitem"><a href=".">Home</a></li>
			<li class="menuitem"><a href="technobyte1.php">Techno Byte</a></li>
			<li class="menuitem"><a href="./Happenings/sportsatpsl.html">Happenings</a></li>
			<li class="selected">Framed</li>
			<li class="menuitemn"><a href="kaleidoscope.php">Kaleidoscope</a></li>
			<li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>
			<li class="menuitem"><a href="contactUs.php">Contact Us</a></li>     
          </ul>             
        </div>  
        <div id="submenu">
 <ul>                                  
            	<li class="selectedleft">                             
              		<a href="#">Framed</a>
				</li>   
			</ul>
        </div>             
        <div id="content">	                   
          <p><img src="files/images/framed/yogesh.jpg" width="307" align="right" height="380" ><b>Fish-4- News team caught up with Yogesh Naik , Senior Software Engineer to find out what is the latest happening in his life.</b></p>
		  
		  <p><b>Name: </b>Yogesh Naik </p>
		  
		  <p><b>Educational background: </b>MCA-Goa University</p>
		  
		  <p><b>Tell us a little on the challenges that you faced while working on the Symbiosis project ? how did you tackle them ?</p></b>
		 <p>The greatest challenge was to meet the tight deadline; we handled it by working hard  and stretching  our work hours .However the hard work paid off !</p>
		  
		  <p><b>One thing that you hate about your job ?</b></p>
		  <p  style="width:320px;text-align: justify;">Facility to do late stay.<img height="16" src="files/images/winking-smiley.gif"> </p>

		  <p><b>What are the 3 important qualities as per you that every software engineer should have for his/her line of job ?</b></p>
		  <p>Smart and hard Working <br>
		    Good technical knowledge<br>
	           Ability to adapt in different situation.<br></p>
		
		  <p><b>You are faced with a situation where your subordinate falsely complains against you during the skip level meeting, how would you handle the situation ?</b></p>
                <p>I don't have a subordinate <img height="20" src="files/images/sad_smiley.gif"> but if this happens to me in future then I'll give him/her, school punishment. MURGA outside the wing.<img height="18" src="files/images/1.gif"> </p>
			 
		  
		  <p><b>When things just don't go your way, what is the first thing that you do ?</b></p>
		  <p style="text-align: justify;">I think all my colleagues in my cubicle know this, I start playing tabala on my desk <img height="18" src="files/images/1.gif"> (sorry for that, can't help).
                   One more thing I do is play TT when I am stuck with problems but only with those whom I can defeat <img height="18" src="files/images/1.gif"> (Get your frustration out on opponent, it works 
                   <img height="16" src="files/images/winking-smiley.gif"> )</p>
		  
		  <p><b>Tell us about one of your best achievements.</b></p>
		  <p style="text-align: justify;">I enjoy each and every achievements in life, big or  small.  The best one so far  is the campus placement in PSL.</p>
		  
		  <p><b>A dream that has come true.</b></p>
		  <p>I am still dreaming about it.<img height="16" src="files/images/winking-smiley.gif"> </p>
		  
		  <p><b>Who inspires you and why?</b></p>
		  <p>My Mom, You can call me "Mamma's boy" for this however she is simply great. <img height="18" src="files/images/1.gif"> </p>
		  
		  <p><b>A country you would always like to visit and why ?</b></p>
               <p>Though I have not travelled out of my country, I would like to visit Spain. It's one of the best holiday destination. </p>
		  
		 <p><b>Your hobbies  ?</b></p>
		<p>Download and watching TV series and movies and hanging out with friends. </p>
		  
		  <p><b>Some of your future goals ?</b></p>
		<p>To improve my technical knowledge and grow with Persistent. Learning at least one musical instrument.</p>

		<p><b>If time nor tide waits for no man what does ?</b></p>
		<p>It means time and tide are biased toward women <img height="18" src="files/images/1.gif">. 
            On a serious note, if something is out of our control like time, it should be managed  properly.</p>
		<p><b> Wish You'll a very happy and prosperous New Year.</b><img height="18" src="files/images/1.gif"></p>
		  
		  
        </div>	
		<img src="files/images/framed/framed-foo_yogesh.jpg" class="signature"/> 
      </div>

      <div id="footer">                                                 
        <p>Copyright &copy; 2012 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>        
    </div>  
  </body>
</html>ss