<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="generator" content=
    "HTML Tidy for Windows (vers 25 March 2009), see www.w3.org" />
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>
      Goa Newletter
    </title>
    <style type="text/css">
/*<![CDATA[*/
    #content p { text-align:justify; margin: 10px;}
    /*]]>*/
    </style>
  </head>
  <body>
    <div id="outdiv">
      <div id="header">
        �
      </div>
      <div id="container">
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" />
        </div>
        <div id="menu">
          <ul>
            <li class="menuitem">
              <a href=".">Home</a>
            </li>
            <li class="menuitem">
              <a href="technobyte.php">Techno Byte</a>
            </li>
            <li class="menuitem">
              <a href="Happenings/sportsatpsl.html">Happenings</a>
            </li>
            <li class="menuitem">
              <a href="framed.php">Framed</a>
            </li>
            <li class="selected">Kaleidoscope
            </li>
            <li class="menuitemn">
              <a href="didyouknow.php">Viva Goem</a>
            </li>
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a>
            </li>
          </ul>
        </div>
        <div id="submenu">
        <ul>
	    
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="selected"><a href="#">CricketNEXT</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>

		
		</ul>
        </div>
        <div id="content">
          <h1>
           CricketNext in India
          </h1>
			<p>While Sachin Tendulkar was loosing his luster and Unmukt Chand was rising in Cricketland, there were boxers, wrestlers, shuttlers, shooters sparkling their way, cementing India at the World stage. London Olympics was the most successful India&rsquo;s performance based on medal standings. While hockey was superlative on paper, tennis had its work cut out due to Lee-Hesh ego clash.</p>
			<p>With bronze in Beijing, Vijender Singh motivated a breed of super Indian boxers and punched the Olympics arena hard, which were once dominated by Cuba, Mangolia, Uzbekistan. Amazed to see India as the new boxing powerhouse, the referees played their part in keeping a check, but they couldn&rsquo;t stop the Magnificent Mary. Residing in a state where Irom Sharmila is on a hunger strike for over a decade, Mary Kom has made it big. A five time women&rsquo;s boxing World champion, a mother of 2 and then giving it all for India, Mary is truly magnificent.</p>
			<p>Leading the Indian Olympic contingent, Sushil kumar&rsquo;s unbelievable win in semifinal bout against Kazakhistan was evident of his hunger for changing the color of his medal, supported by his knowledgeable wrestler wife. Knocked down by the Russian in quarters, Yogeshwar Dutt had his 21 years of hard work finally rewarded in the repechage, fighting 3 bouts in a span of 45 minutes with a bruised eye, revealing his burning desire for a medal.</p>
			<p>With scanty knowledge of Olympics, the dark horse and army man, Vijay Kumar&rsquo;s, mother was preparing the Himachali dish to celebrate her sons feat in a house, located just behind the red brick wall of a cattle shed, on a choola, with glitter in eyes hoping that Vijay&rsquo;s feat will help them beat poverty and replace the clay utensils with steel. Vijay Kumar and Gagan Narang hit the bulls eye, the later had been longing for quiet sometime at this stage.</p>
			
			<p>Saina Nehwal, in an interview said that the Chinese are not invincible and you need to practice for about 14 hours a day, to better them who dedicatedly practice for 13 hours. Rejecting the cricketer&rsquo;s game of endorsing brands, Saina showcased her hard work, dedication, discipline ably mentored by Gopichand made her stand on the podium. With the big fat money, BMW&rsquo;s pouring in for her success, she made it even bigger by gifting cash award to the ParaOlympic High Jump Silver Medalist Girisha Nagrajegowda, understanding the appreciation, encouragement a sportsmen needs.</p>
			<p>Apart from the medal winners, some of the standout performance&rsquo;s from India were Parupalli Kashyap, Jwala Gutta, Ashwini Ponappa in Badminton, Vijender Singh, Devendro Singh, Shiv Thapa, Manoj Kumar, Sumit Sangwan in boxing, Vikas Gowda in Discus throw. With abundance of boxers, wrestlers, shuttlers motivated to compete at the highest level, 4 years from now, Indian Olympic medal count will only increase. Blessed by the Christ standing tall in Rio de Janeiro, we will hear the National Anthem playing time and again making it a priceless moment to every Indian. </p>
			
			<p>&nbsp;</p>
						
			<p>&nbsp;</p>
			
		  </div>

		<div style="background:#F6D797; width:755px; padding:5px 10px 5px 10px">
 					<div style="float:left;"><img src="files/images/saish-footer.png"></div>
					<div style="float:right; padding:40px 0 0 0; width:630px; text-align:right; color:#D98700; font:bold 13px arial; margin:0; vertical-align:bottom; ">
						<em>Article by Saish Cuncoliencar, Senior Software engineer who is part of the Exagrid team, working with Persistent since April 2011 . Saish&rsquo;s hobbies include driving, blogging and is a sports enthusiast. </em>
					</div>
					<div style="clear:both"></div>
		  </div>
      </div>
      <div id="footer">
        <p>
          Copyright &copy; 2012 Persistent Systems Ltd.
        </p>
      </div>
    </div>
  </body>
</html>