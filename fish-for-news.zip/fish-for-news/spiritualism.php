<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="generator" content=
    "HTML Tidy for Windows (vers 25 March 2009), see www.w3.org" />
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>
      Goa Newletter
    </title>
    <style type="text/css">

    #content p { text-align:justify; margin: 10px;line-height:18px;}
  
    </style>
  </head>
  <body>
    <div id="outdiv">
      <div id="header">
        �
      </div>
      <div id="container">
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" />
        </div>
        <div id="menu">
          <ul>
            <li class="menuitem">
              <a href=".">Home</a>
            </li>
            <li class="menuitem">
              <a href="technobyte.php">Techno Byte</a>
            </li>
            <li class="menuitem">
              <a href="Happenings/sportsatpsl.html">Happenings</a>
            </li>
            <li class="menuitem">
              <a href="framed.php">Framed</a>
            </li>
            <li class="selected">Kaleidoscope
            </li>
            <li class="menuitemn">
              <a href="didyouknow.php">Viva Goem</a>
            </li>
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a>
            </li>
          </ul>
        </div>
        <div id="submenu">
        <ul>
	    
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="submenuitem"><a href="guesswho.php">Guess Who?</a></li>
		<li class="selected"><a href="#">Spiritualism</a></li>
		
		</ul>
        </div> 
		
        <div id="content">
          <h1>
            Spiritualism
          </h1>
          <p>Spiritualism, the moment this word is mentioned, people take a seat back and say it's not my cup of tea , lets discuss this when we are old. There are views like &quot;let those who have a liking for Spirituality study it, of what use is it to us?&quot;.  Its an erroneous statement that spiritualism can be practiced in old age. When a person turns old, can anybody tell exactly at what age, spiritualism can be practiced ?. Can anybody guarantee how long a life they have to live on earth?. Body and mind grow weak with  age. Just as it is difficult to learn any new skill in old age, so also it becomes difficult to learn any spiritual practice then. Another disadvantage with age is that  the number of impressions created in the subconscious mind keeps  increasing. In Spirituality, however, one aims at eliminating all these impressions. </p>
          
		  <p>Pessimism in studying spirituality are due to various reasons. 95% due to so-called 'holy men' who sometimes turn out to be fake. Fake people make money under the garb of Spirituality for instance by starting a 'yoga' or a 'Pranayam' (controlled breathing exercises)' class or wearing some orange clothes accompanied with their disciples. The word &quot;Guru&quot; has become more of a  mockery which makes common man think, its best to be  careful, lets no even think of spiritualism.</p>
		 
		  <p>Why do we need spiritualism. Every living being (jiva), from the smallest insect or ant to the more evolved human being, is constantly in the quest for the supreme quality of happiness. However, schools and universities do not teach how to acquire this happiness. Happiness which is everlasting and of supreme quality is called Bliss. The science which teaches how to acquire Bliss is termed the science of Spirituality. Physical sciences cannot explain how to attain Bliss (Anand) which only the science of Spirituality can. Spirituality is the only science which teaches one to observe the problems in day-to-day life with the stance of a spectator and attain bliss. It teaches us what is the truth in life  and what should be the final aim/achievement in human being. That's the reason, Steve Job came to India, to understand what is the real truth of life. It's a different story that Steve did not find the right person and like Steve, many go empty handed too.</p>
          
		  <p>The word Spiritualism is deeply connected with India, for me, India has given this gift to the world. Our base strength lies in spiritualism. This strength was recognized by Lord Macaulay. After Lord Macaulay toured entire India, he addressed the British parliament stating the following .&quot;I have travelled across the length and breadth of India and I have not seen one person who is a beggar, who is a thief. Such wealth I have seen in this country, such high moral values, people of such caliber, that I do not think we would ever conquer this country, unless we break the very backbone of this nation, which is her spiritual and cultural heritage, and therefore, I propose that we replace her old and ancient education system, her culture, for if the Indians think that all that is foreign and english is good and greater than their own, they will loose their self esteem, their native culture and they will become what we want them, a truly dominated nation. &quot;</p>		  
		  
		  <p>Probably Macaulay (an English) understood , the strength and power of Indian culture , education and heritage, than most Indians do today. The educational system commenced by the British in India destroyed the loyalty to Righteousness (Dharma) and increased the desire for wealth. Western concept taught us that  &quot;happiness depends on wealth&quot;. every materialistic gain will give us happiness . Higher the materialistic gain, higher will be the comfort and thus I will be more happier than others. That is how &quot;Money&quot; has become the &quot;Righteousness &quot;  of the new era. The moment we felt that our happiness depends on object pleasure, we started becoming greedy and that is how corruption got it's roots. Corruption is at every single door besides other problems like poverty and population.</p>
          
		  <p>Education system concentrated only on the mind and didn't include the heart and that is how it has created menace to the society. Steven Muller, President, Johns Hopkins University, quoted that education system that is being taught in universities will only give highly skilled barbarians. Through this education, we have lost our wisdom of thinking. </p>
          
		  <p>After taking a slap on one side, we have welcomed the other side with the next slap, motto being , the person giving the slap should have all the satisfaction. We have learned  that  a person is more than a country and country is no more than a person. We are  forgetting our martyrs', our ideals are cinema actors , actress and models, We do not care that our farmer are committing suicide,  &quot;annadata sukhibhava&quot;(Let the food giver lead happy life) is no more our mantra to  express gratitude to the farmers. We do not care that the movie, Slumdog millionaire portrayed India as a very poor and ugly country  with slums, open-air lavatories, riots, underworld, prostitution, brothels, child labour, begging, blinding and maiming of kids. This is message that has reached to people across the world. We don't mind our Ex President, Mr Kalam getting  insulted at the airport , twice. Many of us do not condemn anything which brings the nation down, all we do is we express our unhappiness. In the end, we don't  deserve the  respect because we have not learnt to command it.</p>
		  
		  <p>We want to absorb western culture based on money but we do not want to absorb their values, discipline and self pride. We want more and more money in our bank accounts so so that the next several generations lives a  luxurious life.</p>
		  
            <p>India can go back to a state which Lord Macaulay observed, only by throwing those principles which Lord Macaulay rooted in us. In other words get our identity, self pride, respect for the nation and command respect for India worldwide. All this things will not be possible through today's political parties or anything else. Spiritualism is the only answer and  the one and only solution. Lets have a look at a very important aspect of it, the spiritual path called Gurukrupayog.</p>
			
            <p>Spirituality is a never ending science and what I have will mention here is just a micro portion. We  may have heard of  the  terms Bhaktiyog, Dyanayog, Karmayog, hatayoga . Since it is difficult for the common man to understand all this yog are concluded in Gurukrupayog which is easy to understand and sure shot way of attaining liberation. It has teachings which will not only help shape an individual but will also guarantee liberation. It looks for individual spiritual growth(vyasthti sadhana) as well as spiritual growth of society (samashti sadhana) Gurukrupayog has many facets, I will touch only the Personality defect removal part.</p>

			
          <p>To start with this topic, lets understand what is called as 'impression' since this is what human being is made of as far as his personality is considered. Impression is nothing but Sanskar that is situated deep within you . Millions of impressions do accumulate in subconscious mind and this is the cumulative effect of so many previous birth.  Every birth, either new impression gets created or existing impression go strong. Impression can be bad or good. So human being is made of +ve and �ve impressions and that is what we call as personality. Lets focus on removing these bad impressions and on rooting good impressions. While performing any action, when the same impressions from the sub-conscious mind keep surfacing repeatedly, they are collectively labeled as 'personality'. In short, personality means a person's nature. In many individuals, the occurrence of this happens so often that one can classify them as qualities or defects.</p>
          
		  <p>There is a famous saying in Marathi, it means, a person defects will never go unless he dies or dog's tail can never be straightened however much you try. This is not true. One has to take profound efforts in removing personal defect. Most of the time, a  person's unhappiness lies in its personal defects. This defect could be newly formed impression or impression which has been inherent from previous births. So definitely defect removal cycle takes lot of time depending on its age . Every problem of unhappiness lies in person's personal defects. For an individual to lead a happy life and do effective spiritual practice it is essential that the personality defects are destroyed and qualities are imbibed or developed. Personality defects are the main obstacle in obtaining/experiencing happiness or contentment in one's life. Also they are the main obstacle in one's efforts towards attaining God, i.e. in one's spiritual practice.</p>
		  
		  <p>Can you remove something which is deep rooted ? The answer is Yes. We need to remove our personality defects at least to some extent just to avoid ill-effects at the physical, psychological, society and spiritual level and to be able to lead a fulfilling life. Some removal of our defects also make our personality and the environment around us more conducive to spiritual practice. For more information on this do google for Gurukurpayog. </p>
		  
		  <p>I end this article hoping it has enlighten many minds to the fact that we can make a difference to ourselves and the people around us, if we practice a little bit of spirituality a little every day. We can rise and help our nation to rise to.</p>
		  
		  
        </div>
		
		<p>&nbsp;</p>
		<div style="background:#f6d797; width:755px; padding:5px 10px 5px 10px">
		 <div style="float:left;"><img src="files/images/pranjali_footer.png"></div><div style="float:right; padding:40px 0 0 0; width:600px; text-align:right; color:#b26e01; font:bold 13px arial; margin:0; vertical-align:bottom; ">
		 <em>Article by Pranjali Apte, Lead Process Analyst, who is part of the CQM team ,with Persistent since April 2006.
		</em></div><div style="clear:both"></div>
		</div>
		
      </div>
	  

		
      <div id="footer">
        <p>
          Copyright &copy; 2012 Persistent Systems Ltd.
        </p>
      </div>
    </div>
  </body>
</html>