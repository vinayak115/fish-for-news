<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/red.css" rel="stylesheet" />     
<script src="files/js/jquery-1.7.1.min.js"></script>
    <link href="files/css/fotorama.css" rel="stylesheet">
    <script src="files/js/fotorama.js"></script>    
    	   
    	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/red/banner_red.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>          
            <li class="menuitem"><a href=".">Home</a></li>
	        <li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>          
            <li class="menuitem"><a href="Happenings/prerana.html">Happenings</a></li>          
            <li class="menuitem"><a href="framed.php">Framed</a></li>          
            <li class="menuitem"><a href="kaleidoscope.php">Kaleidoscope</a></li>  
            <li class="selected">Viva Goem</li>
            <li class="menuitemn"><a href="contactUs.php">Contact Us</a></li>                            
          </ul>             
        </div>  
        <div id="submenu">
			<ul>                                                                         
							<li class="left"><a href="didyouknow.php">Did you know</a></li>
				<li class="selected"><a href="#">The Basket Weaver</a></li>  
			</ul>
        </div>             
        <div id="content">	

		
          <div class="articleTitle" style="padding-top:10px;">The Basket Weaver<br  /></div>
<p>It's not an unusual sight around Goa where in you see a fisherwoman carrying a basket with fish on her head and shouting "Nusthe zai Go", which literally means that that you getting fresh fish at your door step, why not avail of it. Those selling fruits would come out with their own version of Konkani words to make their presence felt so that you could  make your purchases of fruit at your door step. One thing common among both these trades are  the humble bamboo basket that is carried around with the goods.</p>		 

 <p>Basket weaving has been an occupation in Goa for many years and the community who has the expertise for this occupation is the Mahar community. Not making an attempt to touch the
 caste system that still prevails in Goa, this article is all about the basket weaver. Mostly settled  in Canacona, the basket weavers have come a long way with a trade which is slowly
 demising  with time. I was lucky to meet, Shardha Mane, a basket weaver  presently staying at the Merces village and who still is proud of her occupation. She explains the art of making
 these baskets which pretty is simple, bamboo trees are searched, once the ideal bamboo is found which is mostly the matured ones, the tender ones will not do to make strong baskets,
 its chopped  skillful into fine strips. On inquiring from where they purchase their bamboos from, she informs mostly  from a hillside or a "dongor" as a Goan would say.
 20 strong and long strips are bound together to form the base of the basket, to these strips, finer strips are chopped and intertwined to  form a basket which are sold nowadays for 200 Rs. </p>
 



		<div align='center'>
		  
<div class="fotorama fotorama_shadows" >
      <img class="borderClass" src="files/images/IMG_VIV_01.JPG"><img src="files/images/IMG_VIV_02.JPG"><img src="files/images/IMG_VIV_03.JPG">
	  <img src="files/images/IMG_VIV_04.JPG">
	  <img src="files/images/IMG_VIV_05.JPG">
    </div>


 </div>


<p>These baskets are mostly used now adays to sell common commodities such as fruits, the leafy vegetables freshly plucked from the agriculture soils  or to store coconuts, 
salt from the salt pans. In addition to this Shardha informed many catholic communities use this basket to store the cooked rice during a wedding or death of a person. This
 helps to drain off all the water from the cooked rice. Some of her neighbors still order the "Panj" to keep the small chicks.  </p>

<p>In the past the Mahar community were very important since traders depended on them for their bamboo and cane implements. The farmers would flock to the 
residence of the Mahar to place order and collect cane and bamboo baskets (panttem, pantleo) and the winnowing fans (sup) and koddo (used to store paddy). 
People of yester years would sleep on woven bamboo mats. Rock salt used to be stored for the monsoon in bamboo containers called mitacheo konno. Hens and roosters 
used to be put in bamboo baskets called koron. Landlords or coconut merchants would order their coconut basket (Vojem) from this community. The dhobis too ordered 
strong baskets from the Mahar community to carry the clothes.   </p>

<p> With time a lot has changed, the fishermen prefer using the plastic version of these baskets similarly the vegetable and the food vendors. On inquiring the
 difficulties faced in this occupation and its fading with time, Shardha explains that basket weaving involves a lot of hard work and is time consuming. The amount
 that is received is pretty less for all the work involved. Shardha says that now a days with the rate of simple goods sky rocketing, it's better to spend the same
 time working in an office rather then making baskets. Another disadvantage to this is with the plastic basket coming out in market which last longer, many of the
 fishermen or the fruit sellers prefer to purchase those. On inquiring  weather her children would like to continue this trade, she sadly informs that they were not
 interested, their taste have differed with all the modernization seen around, the work of the basket weaver has no much value. anymore. The quantity of baskets made
 by her nowadays have dropped considerably however she does manage to make some for her friends and family and a few customers who still need it from time to time. </p>

<p> Shardha still remains with hope that the government will help in reviving this traditional trade. This trade has seen its ups and down, however, this humble basket is a reminder of Goa's yesteryears. The years of hard work with great sincerity , close friendship between neighbors and very  ecofriendly which resulted in peace and harmony.  </p>



	  
		  

		
		  
		  		  
        </div>
		
		<img src="files/images/na1.jpg" class="signature" />
      </div>
      <div id="footer">                                                 
        <p>Copyright &copy; 2013 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>
    </div>  
  </body>
</html>