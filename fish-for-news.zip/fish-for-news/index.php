<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">        
  <head>              
    <link type="text/css" href="files/css/blue.css" rel="stylesheet" />              
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />              
    <title>Goa Newletter              
    </title>           
  </head>        
  <body>           
    <div id="outdiv">         
      <div id="header">           &nbsp;         
      </div>             
      <div id="container">                     
        <div id="banner">          
          <img src="files/images/banner.jpg" alt="banner" />          
        </div>                         
        <div id="menu">                            
         <ul>          
            <li class="selected">
              Home</li>          
            <li class="menuitemn">
            <a href="technobyte.php">Techno Byte</a></li>          
            <li class="menuitem">
              <a href="Happenings/prerana.html">Happenings</a></li>          
            <li class="menuitem">
              <a href="framed.php">Framed</a></li>          
            <li class="menuitem">
              <a href="kaleidoscope.php">Kaleidoscope</a></li>  
             <li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>
         
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a></li>                            
          </ul>                    
        </div>           
        <div id="submenu">        
          <ul>        
       
            <li class="selectedleft">
            <a href="#">From the Editor's Desk</a></li>
                  
          </ul>        
        </div>                      
        <div id="content">	                              
          <p>Dear Readers,
          </p>
          <p><b>It's time once again for Goa's quarterly newsletter!!! Fish-4-News is proud to present its 24th edition of  our newsletter. </b>
          </p> 
		  <p>Here's a peek of what each section has in store for you:</p> 
		  
          <p><strong>Techno Byte</strong> is all about technologies that you wanted to learn about, Shaunak Shilimkhan explains us more on cellular technology while Sandeep Pandey shares in knowledge on NodeJS.</p>
          <p><strong>Happenings</strong> has loads of details of the various events held across PSL-Goa this quarter. All the committees were actively involved in various activities , check out more in this section .Zoggin is the Project of the Quarter.  </p>
		  
          <p>We have <strong>Framed</strong> Savio Mesquita, Project Manager and  earlier, part of the Zoggin team . If you wish to see any colleague featured in Framed, do write to us at <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in </a>.
          </p>
          <p>In <strong>Kaleidoscope</strong> don't miss the talent museum,  it exhibits some of the hidden talents of the PSL-Goa. Take those interesting quizzes in brain teasers, explore a new part of the world in "Where in the world" and read yet another wonderful recipe in Kitchendom.   
          </p>
          <p>In <strong>Viva Goem</strong> learn more about the Mahar community of Goa in the article the basket weaver. <strong>"Did you know"</strong>, features yet another beautiful aspect of Goa captured through the lens.
          </p>
          <p>Please send your contributions for the next quarter Fish-4-News as soon as possible, to 
            <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in </a>
          </p>
          <br>
		  <img src="files/images/ffn_logo.gif" width="162" height="72"  align="right"/>
          <br>
          Cheers!
          <br><strong>Nadia Fernandes</strong>
          <br>Editor - Fish-4-News
          <br>Persistent Systems Ltd.
          <br>Goa.                       
        </div>                                     
      </div>      
      <div id="footer">        
        <p>Copyright &copy; 2013 Persistent Systems Ltd.
        </p>                       
      </div>             
    </div>     
  </body>
</html>