<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/green.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/banner_green.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>
			<li class="menuitem"><a href=".">Home</a></li>
			<li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>
			<li class="menuitem"><a href="./Happenings/prerana.html">Happenings</a></li>
			<li class="selected">Framed</li>
			<li class="menuitemn"><a href="kaleidoscope.php">Kaleidoscope</a></li>
			<li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>
			<li class="menuitem"><a href="contactUs.php">Contact Us</a></li>     
          </ul>             
        </div>  
        <div id="submenu">
 <ul>                                  
            	<li class="selectedleft">                             
              		<a href="#">Framed</a>
				</li>   
			</ul>
        </div>             
        <div id="content">	                   
    
		  
		  <p><img src="files/images/framed/savio-framed.jpg"  align="right" height="290" ><b>An enthusiastic and friendly face is what one would see when you meet Savio Mesquita. 
	Heading the Zogging team at PSL-Goa, here is what Savio shares in his interview with the Fish-4- News team.
</b></p>
		  
		 <p align="left"><b>Name: </b>Savio Mesquita </p>

		 <p align="left"><b>Education background:  </b>Bachelor of Computer Engineering </p>
		  
		  <p align="justify"><b>Tell us a little about how your career started off in this technical line ?  </p></b>
		 <p align="left">Well to be more premise I was more inclined towards the hardware aspects of a computer before I was introduced to the code that brings it alive. I did start of on a 3 month contract with NIO before I pushed off to Pune, Job hunting. I was lucky in my second week to be offered a position with OAS Info Systems as a Team Member. In two year's time journey back to Goa where by heart and mind was; got engaged with Balvin Engineering that really shaped my career and then onto Open Destination after a stint of 6 1/2 years. 4 1/2 years on here I am at PSL since Dec 2012. </p>
		  
		 <p align="justify"><b>When a new  project is assigned to you, what is the first thing that crosses your mind ?</b></p>
		 <p align="justify">I try to answer a few questions on my own; basically, what are the features of the product as envisaged by the customer, what is the business scenario, how many competitors in the area. This allows me to jell well with the client and gain his overall confidence which is a must for successful execution of a project : Customer Confidence.</p>

		 <p align="justify"><b>What are your plans for Zoggin ?</b></p>
               <p align="justify">Well, my plans for Zoggin are tuned to that of its owners. Once we develop a comfortable, profitable user base it would be the right time to scale it to other handheld devices as that is where the future lies. </p>
	
		<p align="justify"><b>How do you keep your team motivated?</b></p>
		<p align="justify">I believe in the concept of involvement to drive motivation. If importance is paid to one's suggestions and thoughts it's the greatest motivation factor. It does not always pay off. I also do stoop down to the level of a developer and jell with their daily activity that gives them the needed confidence level. </p>

		<p align="justify"><b>How do you keep yourself updated with the latest technology happening around the world ? </b></p>
		<p align="justify">That's an easy one. Of course the internet. I prefer technical sites that offer latest break-trough's and articles. Sometimes it's not well understood but down the line it's possible to piece info together. Discovery channels are also of my liking.</p>
		
		<p align="justify"><b>Your favourite electronic gadget ? </b></p>
		<p align="justify">Oh this has changed a lot over time. From the small handheld games when a child to an Atari system in my teens. A 486 DX2 as my first PC was a marvel until I earned my own laptop. Currently I tweak around my mobile  most  of the day, so yes, today, it is my mobile ! </p>

		<p align="justify"><b>A website that you constant refer for any help ? </b></p>
		<p align="justify">I used to often visit MSDN and Codeguru. But as of today I would just say Google as the entry point.</p>

		<p align="justify"><b>2 things that disappoint you ? </b></p>
		<p>State of IT industry in Goa, big disarray from the governance side.</p>

		<p align="justify"><b>What is the thing that you miss when you are at work?</b></p>
		 <p align="justify">My Boys first, football second. ?</p>

		 <p align="justify"><b>The best gift you gave your family till date?</b></p>
		 <p align="justify">The Tata Nano for the school drops. They were more pleased and excited having it than my car. They call it 'Cute Car'</p>

		 <p align="justify"><b>Your favourite sport ? </b></p>
		 <p align="justify">Football and Football..<img height="13" src="files/images/smile.jpg"></p>

		 <p align="justify"><b>Your strengths ?</b></p>
		 <p align="justify">Logical Ability and an ear to listen, understanding. </p>		

				  
        </div>	
		<img src="framed-foo.JPG" class="signature"/> 
      </div>

      <div id="footer">                                                 
        <p>Copyright &copy; 2013 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>        
    </div>  
  </body>
</html>