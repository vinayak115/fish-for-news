<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/green.css" rel="stylesheet" />         
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/banner_green.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>
			<li class="menuitem"><a href=".">Home</a></li>
			<li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>
			<li class="menuitem"><a href="./Happenings/prerana.html">Happenings</a></li>
			<li class="selected">Framed</li>
			<li class="menuitemn"><a href="kaleidoscope.php">Kaleidoscope</a></li>
			<li class="menuitem"><a href="didyouknow.php">Viva Goem</a></li>
			<li class="menuitem"><a href="contactUs.php">Contact Us</a></li>     
          </ul>             
        </div>  
        <div id="submenu">
 <ul>                                  
            	<li class="selectedleft">                             
              		<a href="#">Framed</a>
				</li>   
			</ul>
        </div>             
        <div id="content">	                   
    
		  
		  <p><img src="files/images/framed/siddhesh_framed.jpg"  align="right" height="290" ></p>
		  
		 <p align="left"><b>Name: </b>Sidhesh Ramesh Kamat </p>

		 <p align="left"><b>Education Qualification:  </b>Bachelor of Computer Engineering </p>
		  
		  <p align="justify"><b>What do you enjoy most the INTEL Project ?</p></b>
		 <p align="left">Work in niche product area of Graphics processing unit (GPU). By working on Intel projects, I got opportunity to learn a lot about GPU hardware and graphics driver internals. I find it interesting to learn 3D and Media hardware acceleration concepts and build a comprehensive knowledge base. Besides, we have a good work culture in Intel ODC and very supportive team members.</p>
		  
		 <p align="justify"><b>What are some of the challenges you have faced in your career and how did you over come them ?</b></p>
		 <p align="justify">I was very fortunate to have worked on OpenWave Mobile browser project very early in my career. This project was successfully executed for 5 and half years. It is in this project that I got an opportunity to develop my technical, debugging skills and work on various modules involved in browser application architecture especially layout module. We had to clear issue fixing tests set by client to get this project. This was a challenge then where our entire Openwave team worked hard to ensure that the project is awarded to Goa center. Initially, I followed my curiosity to learn the browser layout module design in depth that helped me to own this module for bug fixing and in implementing complex enhancements reported by client. On gaining relevant experience in the project it was easy to meet the challenges and work was always done before the expected delivery schedule.</br>
		Other challenge I faced was when I visited onsite for Intel. We were told by the client that the core team would give training for the work to be conducted from India after return. However, to my surprise the core engineer there asked me to implement a complete module support by implementing parser in Java, scripting in Ruby and Interfacing logic in C++. There I had to do reverse engineering and study the product requirements first and then implement the logic in different languages. With determined efforts and constant focus I finished the work well ahead of schedule.</p>

		 <p align="justify"><b>Do you think flexibility in learning various computer languages brings stability or would you rather concentrate in being well versed in just one language?</b></p>
               <p align="justify">Do not think we should be restricted by the type of language. Our focus should be on logic and architectural design of the multiple modules involved in the project. If we have a vision and proper understanding of requirements then we can always study the language to implement functionality in optimum way. </p>
	
		<p align="justify"><b>What have you admired about Steve Jobs ?</b></p>
		<p align="justify">As Steve jobs was a college dropout it proves that a professional Degree or good academic scores may not be an indicator of intelligence and talent a person holds. I admire his creative skills and ability to redefine good ideas that were not much successful earlier. </p>

		<p align="justify"><b>If given a chance to swap your life with a famous personality who would it be and why?</b></p>
		<p align="justify">It would be definitely Shri Anna Hazare for his core principles. I believe he is a simple man working for people�s cause without any selfish motive.  </p>
		
		<p align="justify"><b>Do you feel constructive criticism is an opportunity to success? </b></p>
		<p align="justify">Yes. It is very much necessary for continuous improvement. I truly believe in effective democratic setup where views of all stakeholders are respected before arriving at decision. Sometimes it may happen that we are restricted by the way we think and constructive criticism is needed to alter that. It also gives you a confidence to take up the challenge and work with conviction to prove the critics wrong.</p>

		<p align="justify"><b>If given an onsite option, which country would you choose and why ?</b></p>
		<p align="justify">Recently I have been to Intel at folsom, USA.  I liked the work ethics and professionalism followed by Intel engineers. I found this country very well organized in infrastructure, services and social security. During off work time, Shopping, touring places was fun in U.S and also had chance to taste food from different countries. Enjoyed every moment of my stay there. Would love to visit this country again.</p>

		<p align="justify"><b>How do you like to spend your free time ? </b></p>
		<p>I enjoy a cool ride of Goan villages on my bike.</p>

		<p align="justify"><b>What have you admired about nature always and why ?</b></p>
		 <p align="justify">I like Serene greenery and wide biodiversity. I believe, every aspect of nature has some message for us humans to understand. Nature teaches us unity, patience, confidence, peace, purity etc.</p>

		 <p align="justify"><b>Goals yet to be achieved?</b></p>
		 <p align="justify">1. To work on emerging and trendsetter technology, domain.</br>2. To help people in need and support their cause.</br>3. To visit tourist and heritage destinations in India.</p>

		 <p align="justify"><b>A dream worth remembering... </b></p>
		 <p align="justify">Visiting famous places in USA with my friends were definitely some of the most memorable moments.</p>
				  
        </div>	
		<img src="framed-foo.JPG" class="signature"/> 
      </div>

      <div id="footer">                                                 
        <p>Copyright &copy; 2013 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>        
    </div>  
  </body>
</html>