<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">     
  <head>         
    <link type="text/css" href="files/css/red.css" rel="stylesheet" />         
    	   
    <link rel="stylesheet" type="text/css" href="viva_Goem_files/css/jquery.css">
	
	  <script type="text/javascript" src="viva_Goem_files/js/jquery_002.js"></script>
	  <script type="text/javascript" src="viva_Goem_files/js/jquery_003.js"></script>
	  <script type="text/javascript" src="viva_Goem_files/js/jquery.js"></script>
	  <script type="text/javascript" src="viva_Goem_files/js/common.js"></script>
    <script type="text/javascript">
  $(function() {
    $('img.image1').data('sld-desc', 'Whoa! This description is set through elm.data("sld-desc") instead of using the longdesc attribute.<br>And it contains <strong>H</strong>ow <strong>T</strong>o <strong>M</strong>eet <strong>L</strong>adies... <em>What?</em> That aint what HTML stands for? Man...');
    $('img.image1').data('sld-title', 'Title through $.data');
    $('img.image4').data('sld-desc', 'This image is wider than the wrapper, so it has been scaled down');
    $('img.image5').data('sld-desc', 'This image is higher than the wrapper, so it has been scaled down');
    var galleries = $('.sld-gallery').adGallery();
    $('#switch-effect').change(
      function() {
        galleries[0].settings.effect = $(this).val();
        return false;
      }
    );
    $('#toggle-slideshow').click(
      function() {
        galleries[0].slideshow.toggle();
        return false;
      }
    );
    galleries[0].addAnimation('wild',
      function(img_container, direction, desc) {
        var current_left = parseInt(img_container.css('left'), 10);
        var current_top = parseInt(img_container.css('top'), 5);
        if(direction == 'left') {
          var old_image_left = '-'+ this.image_wrapper_width +'px';
          img_container.css('left',this.image_wrapper_width +'px');
          var old_image_top = '-'+ this.image_wrapper_height +'px';
          img_container.css('top', this.image_wrapper_height +'px');
        } else {
          var old_image_left = this.image_wrapper_width +'px';
          img_container.css('left','-'+ this.image_wrapper_width +'px');
          var old_image_top = this.image_wrapper_height +'px';
          img_container.css('top', '-'+ this.image_wrapper_height +'px');
        };
        if(desc) {
          desc.css('bottom', '-'+ desc[0].offsetHeight +'px');
          desc.animate({bottom: 0}, this.settings.animation_speed * 2);
        };
        img_container.css('opacity', 0);
        return {old_image: {left: old_image_left, top: old_image_top, opacity: 0},
                new_image: {left: current_left, top: current_top, opacity: 1},
                easing: 'easeInBounce',
                speed: 2500};
      }
    );
  });
  function debug(str) {
    if(window.console && window.console.log && jQuery.browser.mozilla) {
      console.log(str);
    } else {
      $('#debug').show().val($('#debug').val() + str +'\n');
    }
  }
  </script>
		
	<style type="text/css">
		#gallery {
					padding: 30px;
					background: #FFE6E6;
					-moz-box-shadow: 0 0 8px #888;
					-webkit-box-shadow: 0 0 8px #888;
					box-shadow: 0 0 8px #888;
				} 
	</style>



	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />         
    <title>Goa Newletter         
    </title>        
  </head>     
  <body>      
    <div id="outdiv">  
      <div id="header">    
       &nbsp;  
      </div>      
      <div id="container">            
        <div id="banner">
          <img src="files/images/red/banner_red.jpg" alt="banner" /> 
        </div>                
        <div id="menu">                 
          <ul>          
            <li class="menuitem"><a href=".">Home</a></li>
	     <li class="menuitem"><a href="technobyte.php">Techno Byte</a></li>          
            <li class="menuitem"><a href="Happenings/WAG.html">Happenings</a></li>          
            <li class="menuitem"><a href="framed.php">Framed</a></li>          
            <li class="menuitem"><a href="kaleidoscope.php">Kaleidoscope</a></li>  
            <li class="selected">Viva Goem</li>
            <li class="menuitem"><a href="contactUs.php">Contact Us</a></li>                            
          </ul>             
        </div>
          
  
        <div id="submenu">
			<ul>   
				<li class="left"><a href="didyouknow.php">Did you know</a></li>
				<li class="selected"><a href="#">The Mandovi</a></li>                                                                  
			
			</ul>
        </div>             
        <div id="content">	                   
          <div class="articleTitle" style="padding-top:10px;"><br  /></div>
		
	<b> The Mandovi, a world of comfort and luxury </b> <br>	  
<p>Goa, a  state of multi cuisine,  rich culture and traditions. Here  , every road has a tale to tell. If we go back in time, say around 50 years or so, it was a different story altogether. This tale is about one of its famous hotel , The Mandovi. If you are  wondering why did I pick this hotel of all the 1000 hotels that have sprouted and are still slowly mushrooming in and around Panjim, well my answer would be slowly  revealed as the article takes shape.</p>
<p>Still under the Portuguese regime,  little Goa was  new to a business of handling a  tourism industry that had began taking roots, it was still struggling  due to lack of good facilities around. No doubt it had  some of the best entrepreneurs and business men, but it was all about finding the right  concepts and heading along the correct path. its the year 1951, the 10th solemn exposition of the relics of one of greatest Saint in Christanity, St Francis Xavier. The relics still exist in Goa at the very famous Basilica of Bom Jesus in Old Goa and are considered very sacred, honored and respected by people from all walks of life. Just as today it attracts ten thousands  it still attracted then, the same amount of crowd, only that time they were from Spain, Japan, Portugal, world over. We are talking about the top business men who would be visiting Goa and paying homage to this great saint.</p>
<p>Goa , then, wasn't prepared to handle the creme de la creme, it didn't have  "THE HOTEL". Grabbing this  opportunity , Quenims, the top business family , came up with the idea of constructing one such hotel, right in the heart of the capital . The Mandovi, a name , after the famous river, that still flows by its side till date. </p>
<p>This hotel would be the very  first 5 storied building in Panjim, the very first building having a lift, having 30 luxurious rooms and a huge banquet hall. Considering  the needs of the European, each room had a balcony over looking the Mandovi river so that the guest could sip on their coffee as they smoked a cigar. The glass ware was specially imported all the way from Japan and the cutlery came all the way from  Czechoslovakia. As a special service of the Mandovi, the ladies were offered a red rose every morning along with the breakfast that was served. The special cuisine was prepared in a kitchen that used firewood, was very authentic and aromatic and from the best ingredients. Quality was never compromised ! </p>
<p>This was Mandovi then, today, its still very traditional and honors the best that Goa can offer. I had a chance to speak to the man who has seen this hotel through thick and thin , Mr Satish Prabhu, General Manager, The Mandovi.  Mr Prabhu boast that The Mandovi has set the benchmark for the very traditional Goan prawn curry. He goes on stating that every chef beginning his/her  career in Goa has to  learn the art of blending the right ingredients at the right proportion for the very traditional,  lip smacking Goan curry, and the best place to learn it would be here at The Mandovi. <br></p>
<p>Its other  famous specially that one can indulge in is the very delicious Chicken Xhacuti ( a chicken preparation blend with spices and  coconut), the chicken Cafreal( chicken marinated in spices and deep fried  ) and the prawn balchao (a spicy prawn preparation). The recipe followed to prepare the Cafreal is the one you would find in Mozambique, Africa, thanks to the Portuguese who introduced it first in Goa.</p>
<p>Some of the eminent  personalities that have enjoyed the Mandovi's  hospitality is the Late Mrs. Indira Gandhi,the late, Mr. Rajiv Gandhi, , Mr A.K advani, MR Vajpayee and not forgetting the city planner and the last governor of Goa under the Portuguese rule , Mr Vasal Da Silva. The Mandovi even had the honors to caterer to the holy father, Late Pope John Paul  II when he was staying at the bishop palace, they still caterer to all the famous banquet happening at the Governor palace. </p>
<p>What traditionally still remains is the Xantar de Natal (translated from Portuguese to English would mean Christmas dinner). This festive Christmas dinner buffet began in 1952 and continues till date. The new year is always welcomed with the "Scintilla", a celebration of lights, music and fine cuisine. The special menu  of the season starts of by the 18th of Dec and continues into the new year, till around 3rd Jan. </p>
<p>On inquiring what would be the Chef's special this festive season, Mr Prahu  explains a little on the planned menu which truly has a variety of dishes to pick from, there is the Fish Monte Carlo having 2 sauces, one red the other white in color (to resemble the colors of Christmas), the "Peru racheado" (stuffed turkey), for the Portuguese guest a delicacy called as "Balcahau" ( salted cod fish preparation),  for desserts there is the Yule cake and the plum pudding. Its X'Mas and plum puddings are in huge demands all across India, orders arrive from Delhi, Mumbai, Pune and even from London. These were just the few dishes from the appetizing menu. In addition to this there would be  a blend of Indian cuisine, the best dishes from all over India . Indeed a mouthwatering treat to one and all ! </p>
<p>  Isn't it just amazing what this hotel has to offer ! Truly Goan, truly nostalgic !. Lets not be  penny wise,  pound foolish, this year, here is a hotel just waiting to welcome you with heart warming greeting.  Visit it once, am sure you will be back wanting for more :</p>
		  

		  		  
        </div>
		
		<img src="files/images/na1.jpg" class="signature" />
      </div>
      <div id="footer">                                                 
        <p>Copyright &copy; 2012 Persistent Systems Ltd.                                         
        </p>                                                      
      </div>
    </div>  
  </body>
</html>