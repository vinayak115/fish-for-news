<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <meta name="generator" content="HTML Tidy for Windows (vers 25 March 2009), see www.w3.org" />
    <link type="text/css" href="files/css/orange.css" rel="stylesheet" />
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <title>Goa Newletter</title>
  </head>
  <body>
    <div id="outdiv">
      <div id="header">&nbsp;�</div>
      <div id="container">
        <div id="banner">
          <img src="files/images/orange/banner.jpg" alt="banner" />
        </div>
        <div id="menu">
          <ul>
            <li class="menuitem">
              <a href=".">Home</a>
            </li>
            <li class="menuitem">
              <a href="technobyte.php">Techno Byte</a>
            </li>
            <li class="menuitem">
              <a href="Happenings/prerana.html">Happenings</a>
            </li>
            <li class="menuitem">
              <a href="framed.php">Framed</a>
            </li>
            <li class="selected">Kaleidoscope</li>
            <li class="menuitemn">
              <a href="didyouknow.php">Viva Goem</a>
            </li>
            <li class="menuitem">
              <a href="contactUs.php">Contact Us</a>
            </li>
          </ul>
        </div>
        <div id="submenu">
        <ul>
        
		<li class="left"><a href="kitchendom.php">Kitchendom</a></li>
		<li class="submenuitem"><a href="whereintheworld.php">Where in the world</a></li>
        <li class="submenuitem"><a href="brainteasers.php">Brain Teasers</a></li>
		<li class="submenuitem"><a href="inthespotlight.php">In the spotlight</a></li>
		<li class="selected"><a href="#">Guess Who?</a></li>
		<li class="submenuitem"><a href="talent_museum.php">Talent Museum</a></li>
		<!--<li class="submenuitem"><a href="strings_and_frets.php">Strings And Frets</a></li>-->
		
		</ul>
        </div>
		
        <div id="content">
        <h1>Guess Who?</h1>
        <p style="text-align:center">
        <img src="files/images/guesswho/guess_who_oct_2013.png" alt="Guess Who?"/>
        <br /><br/>Contributed by the Fish-4-News team. Send in your entries to  
        <a href="mailto:goanews@persistent.co.in">goanews@persistent.co.in</a></p>
        <br />
        <br />
        <br />Correct Answer to Guess  who, previous edition of the newsletter was 
        <strong>Amit Naik</strong>
        <br />
        <p style="text-align:center">
          <img src="files/images/guesswho/guess_who_adult_oct_2013.png" alt="Guess Who? Last Entry" />
        </p>
        <strong>Who guessed it right !! </strong>
		<br />
        <br /><strong>Unfortunately no one !</strong> <!--<img src="files/images/1.gif">-->
		<br /><br>
		<!--
		Others who guessed it correctly were:<br />
		<ul>
		<li>Pankaja Khandeparkar</li>
		<li>Sangeeta Pai</li>
		<li>Pawan Khadpe</li>
		<li>Ameya Mardolkar</li>
		<li>Yogesh Naik</li>
		<li>Sanat Keni</li>
		<li>Neha Prabhu Salgaonkar</li>
		<li>Sapana Bilguche</li>
		<li>Rachna Vadala</li>
		<li>Rakesh Raul</li>
		<li>Meryl Fernandes</li>
		<li>Siddhi Sheldenkar</li>
		<li>Uddesh Parob</li>
		<li>Veena Kamat</li>
		<li>Mithal Saglani</li>
		<li>Priyanka Khandeparkar</li>
		<li>Sanjivi Sardesai</li>
		<li>Supriya Gupta</li>
		<li>Dhruti Dedhia</li>
		<li>Amar Pai Fondekar</li>
		<li>Ramchandra Gauns Desai</li>
		</ul>-->
		<br />          
        </div>   <img src="files/images/goa_newsletter_footer.jpg" />
      </div>
      <div id="footer">
        <p>Copyright &copy; 2013 Persistent Systems Ltd.</p>
      </div>
    </div>
  </body>
</html>